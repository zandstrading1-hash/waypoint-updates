import SwiftUI

// Ordinary scrolling navigation instead of a nested popup menu. These are draft
// and display preferences; choosing a mode never starts or replaces a session.
struct PhoneOptions<Setup: View>: View {
    @Environment(\.dismiss) private var dismiss
    @Binding var mode: PlanMode
    @Binding var appearance: String
    @Binding var compactMap: Bool
    @Binding var showRecentPlaces: Bool
    @Binding var satellite: Bool
    let canCenter: Bool
    let center: () -> Void
    @ViewBuilder var setup: () -> Setup

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    modeRow(.hold, title: "Stay in one place", detail: "Set a timer or hold until you stop", icon: "mappin.circle.fill")
                    modeRow(.drive, title: "Drive a route", detail: "Travel between two places", icon: "car.fill")
                    modeRow(.area, title: "Move around an area", detail: "Continuous walking inside your outline", icon: "figure.walk")
                } header: { Text("Plan your next move") } footer: {
                    Text("Choosing a mode changes your draft. Your current session keeps running.")
                }
                Section("Appearance") {
                    HStack(spacing: 8) {
                        theme("system", title: "Auto", icon: "circle.lefthalf.filled")
                        theme("light", title: "Light", icon: "sun.max.fill")
                        theme("dark", title: "Dark", icon: "moon.fill")
                    }.listRowInsets(EdgeInsets(top: 12, leading: 12, bottom: 12, trailing: 12))
                }
                Section("Your map") {
                    Toggle(isOn: $compactMap) { Label("Compact header", systemImage: "rectangle.compress.vertical") }
                        .accessibilityIdentifier("compactHeader")
                    Toggle(isOn: $showRecentPlaces) { Label("Recent places", systemImage: "clock.arrow.circlepath") }
                    Toggle(isOn: $satellite) { Label("Satellite view", systemImage: "globe.americas.fill") }
                    Button(action: center) { Label("Center on current point", systemImage: "location.fill") }
                        .disabled(!canCenter)
                }
                Section("Waypoint") {
                    NavigationLink { setup() } label: {
                        Label("Phone setup & background", systemImage: "iphone")
                    }.accessibilityIdentifier("phoneSetup")
                    NavigationLink { updatesHelp } label: {
                        Label("Updates & app expiry", systemImage: "arrow.triangle.2.circlepath")
                    }.accessibilityIdentifier("updatesHelp")
                }
                Section {
                    Text(Self.version).font(.footnote).foregroundStyle(Color.waypointSecondaryText)
                        .frame(maxWidth: .infinity).accessibilityIdentifier("optionsVersion")
                }.listRowBackground(Color.clear)
            }
            .navigationTitle("Make it yours")
            .navigationBarTitleDisplayMode(.large)
            .toolbar { ToolbarItem(placement: .confirmationAction) {
                Button("Done") { dismiss() }.fontWeight(.semibold).accessibilityIdentifier("closeOptions")
            } }
        }
        .tint(Color.waypoint)
        .presentationDetents([.large])
        .presentationDragIndicator(.visible)
    }

    private func modeRow(_ choice: PlanMode, title: String, detail: String, icon: String) -> some View {
        Button { mode = choice } label: {
            HStack(spacing: 14) {
                Image(systemName: icon).font(.title3).frame(width: 36, height: 44).foregroundStyle(Color.waypoint)
                VStack(alignment: .leading, spacing: 4) {
                    Text(title).font(.body.weight(.semibold)).foregroundStyle(Color.primary)
                    Text(detail).font(.subheadline).foregroundStyle(Color.waypointSecondaryText)
                }.fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 4)
                Image(systemName: mode == choice ? "checkmark.circle.fill" : "circle")
                    .foregroundStyle(mode == choice ? Color.waypoint : Color.secondary)
            }.padding(.vertical, 5).contentShape(Rectangle())
        }.buttonStyle(.plain).accessibilityIdentifier("mode-\(choice.rawValue)")
            .accessibilityAddTraits(mode == choice ? .isSelected : [])
    }

    private func theme(_ value: String, title: String, icon: String) -> some View {
        Button { appearance = value } label: {
            VStack(spacing: 8) {
                Image(systemName: icon).font(.title3)
                Text(title).font(.subheadline.weight(.semibold))
            }.frame(maxWidth: .infinity, minHeight: 70)
                .foregroundStyle(appearance == value ? Color.waypointOnAccent : Color.primary)
                .background(appearance == value ? Color.waypoint : Color(uiColor: .tertiarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 14))
        }.buttonStyle(.plain).accessibilityIdentifier("theme-\(value)")
            .accessibilityAddTraits(appearance == value ? .isSelected : [])
    }

    private var updatesHelp: some View {
        Form {
            Section("Keep the app working") {
                Label("Refresh before 7 days", systemImage: "calendar.badge.clock").font(.headline)
                Text("Free Apple signing lasts seven days. In SideStore, refresh both Waypoint and SideStore before the countdown reaches zero.")
                Text("This renews permission to open the app. It is separate from installing a new Waypoint version.")
            }
            Section("New versions") {
                Text("Wireless updates need a Waypoint source added to SideStore. Once a source is configured, use its Update button instead of selecting an IPA in Files.")
                Text("A Waypoint source is not configured by this update. Use the supplied installation instructions until one is set up.")
            }
            Section("Before updating") {
                Text("Stop & restore, check your real location, and update the existing app without deleting it to preserve setup.")
                Link("SideStore refresh help", destination: URL(string: "https://docs.sidestore.io/docs/faq")!)
            }
        }.navigationTitle("Updates & expiry").navigationBarTitleDisplayMode(.inline)
    }

    private static var version: String {
        "Waypoint \(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "unknown") (\(Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "unknown"))"
    }
}
