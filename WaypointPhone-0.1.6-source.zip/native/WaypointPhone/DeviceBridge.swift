// SPDX-License-Identifier: AGPL-3.0-only
// Location-service connection/ownership sequence adapted from StikDebug 3.1.13,
// IdeviceFFIBridge.swift. See ../THIRD_PARTY.md and ../LICENSE.
import Foundation
import Darwin
import idevice

// Mutable native handles are accessed only on the private serial queue; the
// pairing URL is immutable. This queue confinement supplies Sendable's guarantee.
// No phone credentials leave the app.
final class DeviceBridge: @unchecked Sendable {
    private let queue = DispatchQueue(label: "waypoint.phone.location", qos: .userInitiated)
    private var adapter: OpaquePointer?
    private var handshake: OpaquePointer?
    private var remote: OpaquePointer?
    private var location: OpaquePointer?
    private let pairingURL: URL

    init(pairingURL: URL) { self.pairingURL = pairingURL }

    private func checked(_ error: UnsafeMutablePointer<IdeviceFfiError>?, _ message: String) throws {
        if let error {
            idevice_error_free(error)
            // Do not surface raw native diagnostics, which can contain pairing data.
            throw PhoneFailure.message(message)
        }
    }

    private func close() {
        if let location { location_simulation_free(location); self.location = nil }
        if let remote { remote_server_free(remote); self.remote = nil }
        if let handshake { rsd_handshake_free(handshake); self.handshake = nil }
        if let adapter { adapter_free(adapter); self.adapter = nil }
    }

    private func open() throws {
        if location != nil { return }
        var pairing: OpaquePointer?
        try checked(pairingURL.path.withCString { rp_pairing_file_read($0, &pairing) },
                    "Import a current remote-pairing file for this iPhone. A classic USB pairing file is not sufficient.")
        guard let pairing else { throw PhoneFailure.message("Pairing file is unavailable.") }
        defer { rp_pairing_file_free(pairing) }
        var address = sockaddr_in()
        address.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        address.sin_family = sa_family_t(AF_INET)
        address.sin_port = in_port_t(49152).bigEndian
        guard "10.7.0.1".withCString({ inet_pton(AF_INET, $0, &address.sin_addr) }) == 1 else {
            throw PhoneFailure.message("Invalid local tunnel address.")
        }
        do {
            let result = withUnsafePointer(to: &address) { pointer in
                pointer.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                    tunnel_create_rppairing($0, socklen_t(MemoryLayout<sockaddr_in>.stride),
                        "WaypointPhone", pairing, nil, nil, &adapter, &handshake)
                }
            }
            try checked(result, "Local tunnel failed. Check LocalDevVPN, pairing and network availability.")
            try checked(remote_server_connect_rsd(adapter, handshake, &remote),
                        "Developer service is unavailable. Unlock the phone and prepare its developer image during setup.")
            try checked(location_simulation_new(remote, &location), "Could not open the location service.")
            // location_simulation_new takes ownership of the remote server on success.
            remote = nil
        } catch { close(); throw error }
    }

    func set(_ point: RoutePoint) async throws {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            queue.async {
                do {
                    guard point.valid else { throw PhoneFailure.message("Invalid coordinates.") }
                    try self.open()
                    try self.checked(location_simulation_set(self.location, point.latitude, point.longitude),
                                     "The phone command failed; the current location is unknown.")
                    continuation.resume()
                } catch { self.close(); continuation.resume(throwing: error) }
            }
        }
    }

    func restore() async throws {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            queue.async {
                do {
                    // Reopen for restore after an interrupted session, without setting a point.
                    try self.open()
                    try self.checked(location_simulation_clear(self.location),
                                     "Restore could not be dispatched. Keep the VPN connected and retry.")
                    self.close()
                    continuation.resume()
                } catch { self.close(); continuation.resume(throwing: error) }
            }
        }
    }
}
