import SwiftUI
import MapKit

struct PlaceMatch: Identifiable {
    let id = UUID()
    let place: NamedPlace
    let address: String
}

// Every edit or dismissal invalidates in-flight results. Search only changes a
// draft; this model has no access to PhoneSession or the device bridge.
@MainActor final class PlaceSearchModel: ObservableObject {
    @Published var query = "" {
        didSet {
            // Resigning keyboard focus can commit the same text again. Only a
            // real edit invalidates the search just submitted for that text.
            guard query != oldValue else { return }
            cancel(); matches = []; message = nil
        }
    }
    @Published var matches: [PlaceMatch] = []
    @Published var busy = false
    @Published var message: String?
    private var request: MKLocalSearch?
    private var task: Task<Void, Never>?
    private var generation = UUID()

    var canSearch: Bool { !query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
    func cancel() {
        generation = UUID(); task?.cancel(); task = nil
        request?.cancel(); request = nil; busy = false
    }
    func submit() {
        cancel(); matches = []; message = nil
        let text = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        let parts = text.split(separator: ",", omittingEmptySubsequences: false).map { $0.trimmingCharacters(in: .whitespaces) }
        if parts.count == 2, let lat = Double(parts[0]), let lon = Double(parts[1]) {
            let point = RoutePoint(latitude: lat, longitude: lon)
            guard point.valid else { message = "Use latitude −90 to 90 and longitude −180 to 180."; return }
            matches = [PlaceMatch(place: NamedPlace(name: "Coordinates", point: point), address: text)]
            return
        }
        busy = true
        let ticket = generation
        task = Task { [weak self] in
            guard let self else { return }
            do {
                let found: [PlaceMatch]
                #if WAYPOINT_UI_PREVIEW
                if ProcessInfo.processInfo.arguments.contains("--ui-tests") {
                    try await Task.sleep(for: .milliseconds(text == "slow" ? 2500 : 300))
                    if text == "offline" { throw URLError(.notConnectedToInternet) }
                    found = text == "no matches" ? [] : [
                        PlaceMatch(place: NamedPlace(name: "Test Library", point: .init(latitude: 42.3344, longitude: -83.041)), address: "Public test result · Detroit, Michigan"),
                        PlaceMatch(place: NamedPlace(name: "Test Park", point: .init(latitude: 42.3315, longitude: -83.047)), address: "Public test result · Detroit, Michigan")
                    ]
                } else { found = try await lookup(text) }
                #else
                found = try await lookup(text)
                #endif
                guard !Task.isCancelled, ticket == generation else { return }
                matches = found; busy = false; request = nil; task = nil
                if found.isEmpty { message = "No places found. Try adding a city or postal code." }
            } catch {
                guard !Task.isCancelled, ticket == generation else { return }
                busy = false; request = nil; task = nil
                message = "Search is unavailable. Try again, enter coordinates, or cancel and drop a pin on the map."
            }
        }
    }
    private func lookup(_ text: String) async throws -> [PlaceMatch] {
        let input = MKLocalSearch.Request(); input.naturalLanguageQuery = text
        let search = MKLocalSearch(request: input); request = search
        let response = try await search.start()
        return response.mapItems.prefix(12).compactMap { item in
            let point = RoutePoint(item.placemark.coordinate)
            guard point.valid else { return nil }
            return PlaceMatch(place: NamedPlace(name: item.name ?? "Place", point: point), address: item.placemark.title ?? "Check the pin on the map")
        }
    }
}

struct PlaceSearch: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var model = PlaceSearchModel()
    @FocusState private var focused: Bool
    let recent: [NamedPlace]
    var title = "Find a place"
    let choose: (NamedPlace) -> Void

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                VStack(spacing: 12) {
                    HStack(spacing: 8) {
                        Image(systemName: "magnifyingglass").foregroundStyle(Color.waypointSecondaryText)
                        TextField("", text: $model.query)
                            .foregroundStyle(Color.primary).tint(Color.waypoint)
                            .overlay(alignment: .leading) {
                                if model.query.isEmpty {
                                    Text("Place, address, or coordinates").foregroundStyle(Color.waypointSecondaryText)
                                        .lineLimit(1).allowsHitTesting(false).accessibilityHidden(true)
                                }
                            }
                            .focused($focused).autocorrectionDisabled().textInputAutocapitalization(.words)
                            .submitLabel(.search).onSubmit { submit() }
                            .accessibilityLabel("Place, address, or coordinates").accessibilityIdentifier("placeQuery")
                        if !model.query.isEmpty {
                            Button { model.query = ""; focused = true } label: {
                                Image(systemName: "xmark.circle.fill").foregroundStyle(Color.waypointSecondaryText).frame(width: 44, height: 44)
                            }.accessibilityLabel("Clear search").accessibilityIdentifier("clearSearch")
                        }
                    }.padding(.leading, 14).padding(.trailing, 4).frame(minHeight: 52)
                        .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 14))
                        .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color(uiColor: .separator), lineWidth: 0.5))
                    HStack {
                        Text("Choose a result to preview its pin.").font(.subheadline).foregroundStyle(Color.waypointSecondaryText)
                        Spacer(minLength: 8)
                        Button("Search", action: submit).font(.subheadline.bold())
                            .frame(minWidth: 64, minHeight: 44).buttonStyle(.bordered)
                            .disabled(!model.canSearch || model.busy).accessibilityIdentifier("submitSearch")
                    }
                }.padding(.horizontal, 20).padding(.top, 12).padding(.bottom, 8)
                Divider()
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 0) {
                        if model.busy {
                            ProgressView("Finding places…").frame(maxWidth: .infinity).padding(28).accessibilityIdentifier("searchLoading")
                        } else if let message = model.message {
                            Label(message, systemImage: "magnifyingglass").foregroundStyle(.primary)
                                .padding(20).accessibilityIdentifier("searchMessage")
                        } else if !model.matches.isEmpty {
                            Text("RESULTS").font(.caption.weight(.semibold)).foregroundStyle(Color.waypointSecondaryText).padding(20)
                            ForEach(Array(model.matches.enumerated()), id: \.element.id) { index, match in
                                row(match.place, detail: match.address, icon: "mappin.circle.fill", identifier: "searchResult\(index)")
                            }
                        } else if model.query.isEmpty {
                            Text(recent.isEmpty ? "Search for an address, business, or latitude, longitude." : "RECENT PLACES")
                                .font(recent.isEmpty ? .body : .caption.weight(.semibold)).foregroundStyle(Color.waypointSecondaryText).padding(20)
                            ForEach(Array(recent.enumerated()), id: \.element.id) { index, place in
                                row(place, detail: "Preview on map", icon: "clock.arrow.circlepath", identifier: "recentResult\(index)")
                            }
                        } else {
                            Text("Tap Search or the keyboard’s Search key.").foregroundStyle(Color.waypointSecondaryText).padding(20)
                        }
                    }
                }.scrollDismissesKeyboard(.interactively)
            }.background(Color(uiColor: .systemBackground))
                .navigationTitle(title).navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Cancel") { close() }.accessibilityIdentifier("cancelSearch")
                    }
                    ToolbarItemGroup(placement: .keyboard) {
                        Spacer(); Button("Hide keyboard") { focused = false }
                    }
                }
        }.tint(Color.waypoint).presentationDetents([.large]).presentationDragIndicator(.visible)
            .task { focused = true }
            .onDisappear { model.cancel() }
    }
    private func submit() { focused = false; model.submit() }
    private func close() { model.cancel(); focused = false; dismiss() }
    private func row(_ place: NamedPlace, detail: String, icon: String, identifier: String) -> some View {
        Button {
            model.cancel(); focused = false; choose(place); dismiss()
        } label: {
            HStack(alignment: .top, spacing: 14) {
                Image(systemName: icon).font(.title2).foregroundStyle(Color.waypoint).frame(width: 28)
                VStack(alignment: .leading, spacing: 5) {
                    Text(place.name).font(.headline).foregroundStyle(.primary).fixedSize(horizontal: false, vertical: true)
                    Text(detail).font(.subheadline).foregroundStyle(Color.waypointSecondaryText).fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.right").font(.caption.bold()).foregroundStyle(Color.waypointSecondaryText)
            }.frame(maxWidth: .infinity, minHeight: 48, alignment: .leading).padding(.horizontal, 20).padding(.vertical, 14)
                .contentShape(Rectangle())
        }.buttonStyle(.plain).accessibilityIdentifier(identifier)
        .overlay(alignment: .bottom) { Divider().padding(.leading, 62) }
    }
}
