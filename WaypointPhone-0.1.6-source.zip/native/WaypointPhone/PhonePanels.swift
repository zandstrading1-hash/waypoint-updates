import SwiftUI

extension PhoneView {
    var sessionPage: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                HStack {
                    Text("Session").font(.largeTitle.bold())
                    Spacer()
                    Button { options = true } label: { Image(systemName: "slider.horizontal.3").frame(width: 44, height: 44) }
                        .accessibilityLabel("More options")
                }
                VStack(alignment: .leading, spacing: 10) {
                    Text(session.active ? session.placeName : session.needsRestore ? "Check restoration" : "Ready when you are")
                        .font(.title2.bold())
                    TimelineView(.periodic(from: .now, by: 1)) { _ in
                        Text(session.timerRemaining.map(timerText) ?? (session.holdTimer.plan != nil ? "Connecting…" : session.active ? "Until you stop" : "No active hold"))
                            .font(.system(size: 38, weight: .semibold, design: .rounded)).monospacedDigit()
                            .foregroundStyle(ink).minimumScaleFactor(0.7).lineLimit(1)
                    }
                    if let timer = session.holdTimer.plan {
                        Label(timer.ending.title, systemImage: "arrow.turn.up.right").font(.subheadline)
                    }
                }
                if session.canReplace {
                    HStack {
                        Button("+15 min") { session.extendTimer() }.disabled(session.timerRemaining == nil)
                        Spacer()
                        Button(session.holdTimer.plan == nil ? "Add timer" : "Edit timer") { editActiveTimer() }
                    }.buttonStyle(.bordered).controlSize(.large)
                    if session.holdTimer.plan != nil {
                        Button("Remove timer · keep holding") { session.removeTimer() }.font(.subheadline)
                    }
                }
                if ["driving", "wandering", "paused"].contains(session.phase) {
                    Button(session.phase == "paused" ? "Resume movement" : "Pause and hold") { session.pauseResume() }
                        .buttonStyle(.bordered).controlSize(.large)
                }
                Button("Choose another place") { page = 0 }.buttonStyle(WaypointButton())
                statusView
                backgroundView
                DisclosureGroup("Connection details") { sessionDiagnostics.padding(.top, 8) }
                Text("Timers need Waypoint running in the background. An interrupted timer is checked when execution resumes; a force-quit ends it.")
                    .font(.footnote).foregroundStyle(.secondary)
            }.padding(20)
        }.safeAreaInset(edge: .bottom) {
            restoreControls.padding(.horizontal, 20).padding(.vertical, 8)
                .background(Color(uiColor: .systemBackground))
        }
    }

    func editActiveTimer() {
        let remaining = session.timerRemaining ?? session.holdTimer.plan?.seconds ?? 0
        timerEditor = .init(active: true, draft: TimerDraft(minutes: remaining > 0 ? max(1, Int(ceil(remaining / 60))) : 0,
                                                           ending: session.holdTimer.plan?.ending ?? .restore), sessionID: session.sessionID)
    }

    var setupView: some View {
        NavigationStack {
            setupContent.toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { setup = false } } }
        }.tint(ink)
    }
    var setupContent: some View {
            Form {
                Section("Keep holding") { backgroundView }
                Section("Phone setup") {
                    Label(session.pairingReady ? "Pairing file ready" : "Pairing file needed", systemImage: session.pairingReady ? "checkmark.circle" : "exclamationmark.circle")
                    Text("Keep LocalDevVPN connected. Initial pairing and developer setup use a computer; the app connects locally on your iPhone during use.")
                        .font(.footnote)
                    Button(session.pairingReady ? "Replace private pairing file" : "Import private pairing file") {
                        setup = false; options = false
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { importing = true }
                    }.disabled(!session.canEdit)
                    Text("Pairing stays in protected app storage and is excluded from backups. Restore and confirm normal location before replacing it.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                ConnectionCheckView(allowed: session.canEdit)
                Section("Timers & switching") {
                    Text("Choose Until I stop, a preset, or a custom timer. At the end, restore real location or switch instantly to another place and keep holding there.")
                    Text("Map browsing changes only your draft. Switch here now applies it without clearing the current session first. A replacement cancels the previous timer.")
                    Text("New timers count from the first successful command. Driving and area timers also count time spent moving or paused. iOS interruptions can delay the ending action; nothing resumes automatically after reopening a terminated app.")
                }.font(.footnote)
                Section("Find My accessories") {
                    Text("Changes can also affect nearby accessories in Find My, including AirPods. After restoring, check both your phone and accessories.")
                }.font(.footnote)
                Section("About") {
                    Text("Long locked-screen holds, fresh cellular startup, and sharing-app refreshes still need separate device testing.")
                    Text("Free signing usually needs renewal every 7 days. Use SideStore to refresh with its required network setup.")
                    Text("Recent places and session coordinates stay in memory only. The app never replays a saved location on launch.")
                    Text("Waypoint \(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "unknown") (\(Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "unknown"))")
                }.font(.footnote)
            }.navigationTitle("Phone setup").navigationBarTitleDisplayMode(.inline)
    }
    var statusView: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(session.phase.replacingOccurrences(of: "-", with: " ").uppercased())
                .font(.caption.weight(.semibold)).foregroundStyle(.secondary)
            Text(session.message).font(.subheadline)
            if let sent = session.sentAt {
                HStack { Text("Last command:"); Text(sent, style: .relative); Text("ago") }
                    .font(.caption).foregroundStyle(.secondary)
            }
            if session.retryCount > 0 { Text("Reconnect attempts: \(session.retryCount)").font(.caption) }
            if session.commandGaps > 0 && (session.active || session.needsRestore) {
                Label("\(session.commandGaps) command gap(s); longest \(Int(session.longestCommandGap)) seconds. Check actual location.", systemImage: "exclamationmark.triangle")
                    .font(.footnote).foregroundStyle(.orange)
            }
        }
    }

    var sessionDiagnostics: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Connection details").font(.headline)
            Text(session.backgroundDiagnostic).font(.footnote)
            LabeledContent("App state", value: session.visibility)
            LabeledContent("Commands while off screen", value: String(session.backgroundCommands))
            LabeledContent("Location-service callbacks", value: String(session.locationCallbacks))
            Text("These counts help diagnose interruptions. Only checking Maps and the sharing apps confirms the displayed location.")
                .font(.caption).foregroundStyle(.secondary)
        }.font(.footnote).padding(14).frame(maxWidth: .infinity, alignment: .leading)
            .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))
    }

    var backgroundView: some View {
        VStack(alignment: .leading, spacing: 8) {
            Toggle("Keep holding when I switch apps", isOn: $session.backgroundHolding)
                .font(.subheadline.weight(.medium)).disabled(session.phase == "stopping")
            Label(session.backgroundStatus, systemImage: session.backgroundRunning ? "location.circle" : "exclamationmark.triangle")
                .font(.footnote).foregroundStyle(.secondary)
            Text("Switch apps or go to Home while this is enabled. Swiping Waypoint away stops its process and can end the hold.")
                .font(.footnote).foregroundStyle(.secondary)
            if session.backgroundHolding && session.canEdit && !session.backgroundRunning {
                Button("Check location permission") { session.requestBackgroundPermission() }.font(.footnote)
            }
        }.padding(12).frame(maxWidth: .infinity, alignment: .leading)
            .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))
    }

}
