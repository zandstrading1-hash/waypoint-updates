import Foundation

struct NamedPlace: Identifiable, Equatable, Sendable {
    let id: UUID
    let name: String
    let point: RoutePoint
    init(name: String, point: RoutePoint) {
        id = UUID(); self.name = name; self.point = point
    }
}

enum HoldEnding: Equatable, Sendable {
    case restore
    case switchTo(NamedPlace)

    var title: String {
        switch self {
        case .restore: return "Restore real location"
        case .switchTo(let place): return "Switch to \(place.name)"
        }
    }
}

struct HoldTimerPlan: Equatable, Sendable {
    let seconds: TimeInterval
    let ending: HoldEnding
    var valid: Bool {
        guard seconds.isFinite, (1...86_400).contains(seconds) else { return false }
        if case .switchTo(let place) = ending { return place.point.valid }
        return true
    }
}

// In-memory only. The caller supplies elapsed ContinuousClock time, which includes
// sleep and is independent of wall-clock/time-zone changes. A new app starts empty.
struct HoldTimer {
    private(set) var plan: HoldTimerPlan?
    private(set) var deadline: TimeInterval?

    mutating func prepare(_ next: HoldTimerPlan?) {
        precondition(next == nil || next!.valid)
        plan = next; deadline = nil
    }

    // Count from the first acknowledged write, never restart after reconnecting.
    mutating func acknowledge(at now: TimeInterval) {
        guard let plan, deadline == nil else { return }
        deadline = now + plan.seconds
    }

    func remaining(at now: TimeInterval) -> TimeInterval? {
        deadline.map { max(0, $0 - now) }
    }

    mutating func takeDue(at now: TimeInterval) -> HoldEnding? {
        guard let deadline, now >= deadline, let plan else { return nil }
        self.plan = nil; self.deadline = nil
        return plan.ending
    }

    @discardableResult
    mutating func extend(by seconds: TimeInterval, at now: TimeInterval) -> Bool {
        guard seconds.isFinite, seconds > 0, let deadline, now < deadline,
              deadline - now + seconds <= 86_400 else { return false }
        self.deadline = deadline + seconds
        return true
    }

    mutating func cancel() { plan = nil; deadline = nil }
}
