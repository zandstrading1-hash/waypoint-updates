import Foundation

struct AreaPoint: Sendable {
    let x: Double
    let y: Double
    func distance(to other: Self) -> Double { hypot(other.x - x, other.y - y) }
    func toward(_ other: Self, fraction: Double) -> Self {
        .init(x: x + (other.x - x) * fraction, y: y + (other.y - y) * fraction)
    }
}

// A small, user-drawn convex area, projected to meters. It describes allowed
// coordinates, not inferred building walls, floors, or actual indoor positioning.
struct IndoorArea: Sendable {
    static let margin = 2.0
    let vertices: [RoutePoint]
    let squareMeters: Double
    private let origin: RoutePoint
    private let longitudeScale: Double
    private let boundary: [AreaPoint]
    fileprivate let interior: [AreaPoint]
    private static let latitudeScale = 6_371_008.8 * Double.pi / 180

    init(_ vertices: [RoutePoint]) throws {
        guard (3...12).contains(vertices.count), vertices.allSatisfy({ $0.valid && abs($0.latitude) < 80 }) else {
            throw PhoneFailure.message("Mark 3–12 corners inside the building, in order around its edge.")
        }
        let origin = vertices[0]
        let scale = Self.latitudeScale * cos(origin.latitude * .pi / 180)
        var polygon = vertices.map { point in
            AreaPoint(x: Self.longitudeDelta(point.longitude - origin.longitude) * scale,
                      y: (point.latitude - origin.latitude) * Self.latitudeScale)
        }
        guard polygon.allSatisfy({ hypot($0.x, $0.y) <= 500 }) else {
            throw PhoneFailure.message("Choose a smaller indoor area, within 500 meters.")
        }
        if Self.signedArea(polygon) < 0 { polygon.reverse() }
        let size = Self.signedArea(polygon)
        guard (25...40_000).contains(size) else {
            throw PhoneFailure.message("Choose an area between 25 and 40,000 square meters.")
        }
        for index in polygon.indices {
            let a = polygon[index], b = polygon[(index + 1) % polygon.count]
            // Every vertex must be inside every edge: rejects concave shapes,
            // crossed outlines, duplicate corners, and reversed interior edges.
            guard a.distance(to: b) >= 2,
                  polygon.allSatisfy({ Self.edgeDistance($0, a, b) >= -0.00001 }) else {
                throw PhoneFailure.message("Corners must form one convex area without crossings or inward bends. Use a smaller area inside the building.")
            }
        }
        var inset = polygon
        for index in polygon.indices {
            let a = polygon[index], b = polygon[(index + 1) % polygon.count]
            var clipped: [AreaPoint] = []
            guard !inset.isEmpty else { break }
            for edge in inset.indices {
                let from = inset[edge], to = inset[(edge + 1) % inset.count]
                let d1 = Self.edgeDistance(from, a, b) - Self.margin
                let d2 = Self.edgeDistance(to, a, b) - Self.margin
                if d1 >= 0 { clipped.append(from) }
                if (d1 >= 0) != (d2 >= 0) {
                    clipped.append(from.toward(to, fraction: d1 / (d1 - d2)))
                }
            }
            inset = clipped
        }
        guard inset.count >= 3, Self.signedArea(inset) >= 4 else {
            throw PhoneFailure.message("That area is too narrow for a 2-meter inset. Mark a wider area that stays inside the building.")
        }
        self.origin = origin; longitudeScale = scale
        boundary = polygon; interior = inset; squareMeters = size
        self.vertices = polygon.map { p in
            .init(latitude: origin.latitude + p.y / Self.latitudeScale,
                  longitude: Self.longitudeDelta(origin.longitude + p.x / scale))
        }
    }

    var center: RoutePoint { coordinate(centerXY) }
    fileprivate var centerXY: AreaPoint {
        .init(x: interior.map(\.x).reduce(0, +) / Double(interior.count),
              y: interior.map(\.y).reduce(0, +) / Double(interior.count))
    }

    func contains(_ point: RoutePoint, inset: Double = 0) -> Bool {
        guard point.valid, inset.isFinite, inset >= 0 else { return false }
        let local = AreaPoint(x: Self.longitudeDelta(point.longitude - origin.longitude) * longitudeScale,
                              y: (point.latitude - origin.latitude) * Self.latitudeScale)
        return boundary.indices.allSatisfy {
            Self.edgeDistance(local, boundary[$0], boundary[($0 + 1) % boundary.count]) >= inset - 0.00001
        }
    }

    fileprivate func coordinate(_ point: AreaPoint) -> RoutePoint {
        .init(latitude: origin.latitude + point.y / Self.latitudeScale,
              longitude: Self.longitudeDelta(origin.longitude + point.x / longitudeScale))
    }

    fileprivate func destination(using random: inout IndoorRandom) -> AreaPoint {
        // Convex combinations stay inside the inset polygon. Avoid points right
        // on its boundary and use changing destinations rather than GPS jumps.
        let first = interior[Int(random.next() % UInt64(interior.count))]
        let second = interior[Int(random.next() % UInt64(interior.count))]
        let alongEdge = first.toward(second, fraction: random.unit())
        return centerXY.toward(alongEdge, fraction: random.between(0.2, 0.9))
    }

    private static func longitudeDelta(_ value: Double) -> Double {
        let wrapped = (value + 180).truncatingRemainder(dividingBy: 360)
        return (wrapped < 0 ? wrapped + 360 : wrapped) - 180
    }
    private static func edgeDistance(_ p: AreaPoint, _ a: AreaPoint, _ b: AreaPoint) -> Double {
        ((b.x - a.x) * (p.y - a.y) - (b.y - a.y) * (p.x - a.x)) / max(0.000001, a.distance(to: b))
    }
    private static func signedArea(_ points: [AreaPoint]) -> Double {
        guard points.count >= 3 else { return 0 }
        return points.indices.reduce(0.0) { sum, index in
            let a = points[index], b = points[(index + 1) % points.count]
            return sum + a.x * b.y - b.x * a.y
        } / 2
    }
}

// Seed injection makes boundary/speed checks repeatable. Production uses a fresh
// system-generated seed for each explicitly started session.
struct IndoorRandom: Sendable {
    private var state: UInt64
    init(seed: UInt64) { state = seed }
    mutating func next() -> UInt64 {
        state &+= 0x9E3779B97F4A7C15
        var value = state
        value = (value ^ (value >> 30)) &* 0xBF58476D1CE4E5B9
        value = (value ^ (value >> 27)) &* 0x94D049BB133111EB
        return value ^ (value >> 31)
    }
    mutating func unit() -> Double { Double(next() >> 11) / 9_007_199_254_740_992 }
    mutating func between(_ lower: Double, _ upper: Double) -> Double { lower + unit() * (upper - lower) }
}

struct IndoorMotion: Sendable {
    let area: IndoorArea
    private var random: IndoorRandom
    private var current: AreaPoint
    private var target: AreaPoint?
    private let walkingSpeed = 1.0
    var point: RoutePoint { area.coordinate(current) }

    init(area: IndoorArea, seed: UInt64 = UInt64.random(in: .min ... .max)) {
        self.area = area; current = area.centerXY; random = IndoorRandom(seed: seed)
    }

    mutating func advance(seconds: Double) -> RoutePoint {
        // Pauses and reconnects call no advance at all. A delayed frame cannot
        // catch up by jumping around the area after the app was suspended.
        guard seconds.isFinite, seconds > 0, seconds <= 5 else { return point }
        var remaining = seconds
        while remaining > 0 {
            if target == nil {
                // Avoid zero-length segments and tiny back-and-forth steps.
                // A bounded search with a farthest-vertex fallback also makes
                // progress deterministic for very small valid outlines.
                var destination = area.destination(using: &random)
                for _ in 0..<8 where current.distance(to: destination) < 1 {
                    destination = area.destination(using: &random)
                }
                if current.distance(to: destination) < 1 {
                    destination = area.interior.max { current.distance(to: $0) < current.distance(to: $1) }!
                }
                target = destination
            }
            guard let destination = target else { break }
            let distance = current.distance(to: destination)
            let duration = distance / walkingSpeed
            if duration <= remaining {
                current = destination; remaining -= duration; target = nil
            } else {
                current = current.toward(destination, fraction: remaining / duration)
                remaining = 0
            }
        }
        return point
    }
}
