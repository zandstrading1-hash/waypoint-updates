import Foundation
import Combine
import Network

// Tests only whether a new TCP connection can reach the local pairing port.
// No pairing record is read and no location, clear, or protocol payload is sent.
@MainActor
final class ConnectionCheck: ObservableObject {
    enum Outcome: Equatable, Sendable {
        case reachable, refused, unavailable, timedOut
        var title: String {
            switch self {
            case .reachable: "Local connection reachable"
            case .refused: "Local connection refused"
            case .unavailable: "Local connection unavailable"
            case .timedOut: "Local connection timed out"
            }
        }
        var detail: String {
            switch self {
            case .reachable:
                "The local port accepted a new connection. This does not verify pairing, holding, or restoration."
            case .refused:
                "The local port refused a new connection. If this happens only on cellular, return to Wi-Fi before starting or restoring."
            case .unavailable, .timedOut:
                "The local port could not be reached. Check LocalDevVPN and compare this check on Wi-Fi and cellular."
            }
        }
    }
    typealias Driver = (@escaping @Sendable (Outcome) -> Void) -> (() -> Void)
    @Published private(set) var running = false
    @Published private(set) var outcome: Outcome?
    @Published private(set) var elapsed: TimeInterval?
    private let driver: Driver
    private let timeout: Duration
    private var identity: UUID?
    private var cancelDriver: (() -> Void)?
    private var deadline: Task<Void, Never>?
    private var started = ContinuousClock.now

    init(timeout: Duration = .seconds(4), driver: Driver? = nil) {
        self.timeout = timeout
        #if WAYPOINT_UI_PREVIEW
        var attempt = 0
        self.driver = driver ?? { reply in
            attempt += 1
            // The first UI check stays pending until the user cancels it.
            // Lifecycle checks separately test timeouts with an injected driver.
            if attempt == 1 { return {} }
            let pending = DispatchWorkItem { reply(.refused) }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2, execute: pending)
            return { pending.cancel() }
        }
        #else
        self.driver = driver ?? Self.connect
        #endif
    }

    func run() {
        cancel()
        let id = UUID()
        identity = id; started = .now
        outcome = nil; elapsed = nil; running = true
        cancelDriver = driver { [weak self] result in
            Task { @MainActor [weak self] in self?.finish(result, id: id) }
        }
        deadline = Task { [weak self, timeout] in
            do { try await Task.sleep(for: timeout) } catch { return }
            self?.finish(.timedOut, id: id)
        }
    }

    func cancel() {
        identity = nil
        deadline?.cancel(); deadline = nil
        cancelDriver?(); cancelDriver = nil
        running = false
    }

    private func finish(_ result: Outcome, id: UUID) {
        guard identity == id else { return }
        let duration = started.duration(to: .now).components
        cancel()
        elapsed = Double(duration.seconds) + Double(duration.attoseconds) / 1e18
        outcome = result
    }

    private static func connect(_ reply: @escaping @Sendable (Outcome) -> Void) -> (() -> Void) {
        let connection = NWConnection(host: "10.7.0.1", port: 49152, using: .tcp)
        connection.stateUpdateHandler = { state in
            switch state {
            case .ready: reply(.reachable)
            case .failed(let error), .waiting(let error):
                if case .posix(.ECONNREFUSED) = error { reply(.refused) }
                else { reply(.unavailable) }
            default: break
            }
        }
        connection.start(queue: DispatchQueue(label: "waypoint.connection-check"))
        return { connection.stateUpdateHandler = nil; connection.cancel() }
    }
}
