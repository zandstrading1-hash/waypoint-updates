import Foundation

// Own playback independently of navigation. Retired work may finish a native
// command already in progress, but may neither publish it nor send another one.
@MainActor
final class SessionPlayback {
    private var generation = UUID()
    private var task: Task<Void, Never>?
    var identity: UUID { generation }

    @discardableResult
    func start(_ operation: @escaping @MainActor (UUID) async -> Void) -> Task<Void, Never> {
        cancel()
        let token = generation
        let next = Task { await operation(token) }
        task = next
        return next
    }

    func cancel() {
        generation = UUID()
        task?.cancel()
        task = nil
    }

    func accepts(_ token: UUID) -> Bool {
        generation == token && !Task.isCancelled
    }

    static func canReplace(phase: String) -> Bool {
        ["holding", "driving", "wandering", "paused", "arrived"].contains(phase)
    }
}
