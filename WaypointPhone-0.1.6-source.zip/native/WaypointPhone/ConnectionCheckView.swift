import SwiftUI

struct ConnectionCheckView: View {
    let allowed: Bool
    @StateObject private var check = ConnectionCheck()

    init(allowed: Bool) {
        self.allowed = allowed
        #if WAYPOINT_UI_PREVIEW
        _check = StateObject(wrappedValue: ConnectionCheck(timeout: .seconds(30)))
        #endif
    }

    var body: some View {
        Section("Wi-Fi & cellular") {
            Text("Check the local connection without changing your location. Run once on Wi-Fi, then on cellular, with LocalDevVPN connected.")
                .font(.footnote)
            Button {
                if check.running { check.cancel() } else { check.run() }
            } label: {
                HStack {
                    if check.running { ProgressView() }
                    Text(check.running ? "Cancel check" : "Check connection")
                }
            }.disabled(!allowed).accessibilityIdentifier("checkConnection")
            if check.running {
                Text("Up to 4 seconds while this screen is open").font(.caption)
            }
            if let result = check.outcome {
                Text(result.title).font(.headline).accessibilityIdentifier("connectionCheckResult")
                Text(result.detail).font(.footnote)
                if let seconds = check.elapsed {
                    Text("Checked in \(seconds, specifier: "%.1f") seconds").font(.caption).foregroundStyle(.secondary)
                }
            }
            if !allowed {
                Text("Stop, verify your real location, and confirm restoration before checking a new connection.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            Text("A working Wi-Fi session may continue on cellular. Starting fresh or reconnecting on cellular is not established. A successful check does not prove location restoration.")
                .font(.footnote).foregroundStyle(.secondary)
        }
        .onDisappear { check.cancel() }
        .onChange(of: allowed) { _, value in if !value { check.cancel() } }
    }
}
