import SwiftUI
import MapKit

extension Color {
    static let waypointSecondaryText = Color(uiColor: UIColor { traits in
        traits.userInterfaceStyle == .dark
            ? UIColor(red: 0.72, green: 0.76, blue: 0.80, alpha: 1)
            : UIColor(red: 0.32, green: 0.37, blue: 0.42, alpha: 1)
    })
    static let waypoint = Color(uiColor: UIColor { traits in
        traits.userInterfaceStyle == .dark
            ? UIColor(red: 0.57, green: 0.95, blue: 0.77, alpha: 1)
            : UIColor(red: 0.02, green: 0.34, blue: 0.27, alpha: 1)
    })
    static let waypointSurface = Color(uiColor: UIColor { traits in
        traits.userInterfaceStyle == .dark
            ? UIColor(red: 0.07, green: 0.10, blue: 0.12, alpha: 1) : .white
    })
    static let waypointOnAccent = Color(uiColor: UIColor { traits in
        traits.userInterfaceStyle == .dark ? .black : .white
    })
}

struct WaypointButton: ButtonStyle {
    @Environment(\.colorScheme) private var theme
    @Environment(\.isEnabled) private var enabled
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.font(.headline).frame(maxWidth: .infinity).padding(.vertical, 16)
            .foregroundStyle(theme == .dark ? Color.black : .white)
            .background(Color.waypoint, in: RoundedRectangle(cornerRadius: 14))
            .opacity(!enabled ? 0.35 : configuration.isPressed ? 0.75 : 1)
    }
}

struct TimerDraft: Equatable {
    var minutes = 0
    var ending: HoldEnding = .restore
    var plan: HoldTimerPlan? {
        minutes == 0 ? nil : HoldTimerPlan(seconds: Double(minutes * 60), ending: ending)
    }
}

struct TimerPresets: View {
    @Binding var draft: TimerDraft
    var custom: () -> Void
    var body: some View {
        HStack(spacing: 2) {
            preset("Until I stop", minutes: 0)
            preset("15m", minutes: 15)
            preset("30m", minutes: 30)
            Button(draft.minutes > 0 && draft.minutes != 15 && draft.minutes != 30 ? "\(draft.minutes)m" : "Custom", action: custom)
                .frame(maxWidth: .infinity, minHeight: 36)
                .foregroundStyle(selectedCustom ? Color.waypointOnAccent : .primary)
                .background(selectedCustom ? Color.waypoint : .clear, in: RoundedRectangle(cornerRadius: 9))
                .accessibilityLabel("Custom timer duration")
        }.font(.subheadline).buttonStyle(.plain).padding(3)
            .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))
    }
    private var selectedCustom: Bool { ![0, 15, 30].contains(draft.minutes) }
    private func preset(_ title: String, minutes: Int) -> some View {
        Button { draft.minutes = minutes } label: {
            Text(title).frame(maxWidth: .infinity, minHeight: 36)
                .fontWeight(draft.minutes == minutes ? .semibold : .regular)
                .foregroundStyle(draft.minutes == minutes ? Color.waypointOnAccent : .primary)
                .background(draft.minutes == minutes ? Color.waypoint : .clear, in: RoundedRectangle(cornerRadius: 9))
        }.accessibilityAddTraits(draft.minutes == minutes ? .isSelected : [])
    }
}

struct TimerEditor: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var theme
    @State var draft: TimerDraft
    let recent: [NamedPlace]
    let save: (TimerDraft) -> Void
    @State private var choosingPlace = false
    @State private var moveAtEnd = false
    @State private var destination: NamedPlace?
    var body: some View {
        NavigationStack {
            Form {
                Section("How long?") {
                    Toggle("Until I stop", isOn: Binding(get: { draft.minutes == 0 }, set: { draft.minutes = $0 ? 0 : 30 }))
                    if draft.minutes > 0 {
                        Picker("Hours", selection: Binding(get: { draft.minutes / 60 }, set: { draft.minutes = max(1, min(1440, $0 * 60 + draft.minutes % 60)) })) {
                            ForEach(0..<25) { Text("\($0) h").tag($0) }
                        }
                        Picker("Minutes", selection: Binding(get: { draft.minutes % 60 }, set: { draft.minutes = max(1, min(1440, draft.minutes / 60 * 60 + $0)) })) {
                            ForEach(0..<60) { Text("\($0) min").tag($0) }
                        }
                    }
                }
                if draft.minutes > 0 {
                    Section("When the timer ends") {
                        Picker("Action", selection: $moveAtEnd) {
                            Text("Restore real location").tag(false)
                            Text("Switch to another place").tag(true)
                        }.pickerStyle(.inline).labelsHidden()
                        if moveAtEnd {
                            Button { choosingPlace = true } label: {
                                Label(destination?.name ?? "Choose destination", systemImage: "mappin.and.ellipse")
                            }.accessibilityIdentifier("timerDestination")
                            Text("Switches instantly, then holds there until you stop. No driving route or intermediate restore.")
                                .font(.footnote).foregroundStyle(.secondary)
                        }
                    }
                }
                Section {
                    Text("A new timer starts with the first successful location command. Editing a running timer starts a new countdown now. Route and area timers include time spent moving or paused.")
                    Text("Waypoint must keep running in the background. If iOS interrupts it, the action can run late. Force-quitting stops the timer.")
                }.font(.footnote).foregroundStyle(.secondary)
            }
            .navigationTitle("Hold timer").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        draft.ending = moveAtEnd ? destination.map(HoldEnding.switchTo) ?? .restore : .restore
                        save(draft); dismiss()
                    }.disabled(draft.minutes > 0 && moveAtEnd && destination == nil)
                }
            }
            .onAppear {
                if case .switchTo(let place) = draft.ending { destination = place; moveAtEnd = true }
            }
            .sheet(isPresented: $choosingPlace) {
                PlacePicker(recent: recent) { destination = $0 }.preferredColorScheme(theme)
            }
        }.tint(Color.waypoint)
    }
}

// A separate destination draft: selecting a timer ending never changes the
// running session or the main map's selected location.
struct PlacePicker: View {
    @Environment(\.dismiss) private var dismiss
    let recent: [NamedPlace]
    let choose: (NamedPlace) -> Void
    @State private var selected: NamedPlace?
    @State private var searchPresented = false
    @Environment(\.colorScheme) private var theme
    @State private var camera: MapCameraPosition = .region(.init(center: .init(latitude: 42.3384, longitude: -83.0245), span: .init(latitudeDelta: 0.08, longitudeDelta: 0.08)))
    var body: some View {
        NavigationStack {
            VStack(spacing: 12) {
                Button { searchPresented = true } label: {
                    Label("Find a place or address", systemImage: "magnifyingglass")
                        .frame(maxWidth: .infinity, minHeight: 48, alignment: .leading).padding(.horizontal)
                        .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 14))
                }.buttonStyle(.plain).padding(.horizontal).accessibilityIdentifier("destinationSearch")
                Text("Search or tap the map, then confirm your destination.")
                    .font(.subheadline).foregroundStyle(.secondary).padding(.horizontal)
                MapReader { proxy in
                    Map(position: $camera) {
                        if let selected { Marker(selected.name, coordinate: selected.point.coordinate).tint(Color.waypoint) }
                    }.onTapGesture { location in
                        if let coordinate = proxy.convert(location, from: .local) {
                            selected = NamedPlace(name: "Dropped pin", point: RoutePoint(coordinate))
                        }
                    }
                }
                Button(selected.map { "Use \($0.name)" } ?? "Choose a pin or search result") {
                    if let selected { choose(selected); dismiss() }
                }.buttonStyle(WaypointButton()).disabled(selected == nil).padding(.horizontal)
            }.padding(.bottom)
                .navigationTitle("Timer destination").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } } }
        }.tint(Color.waypoint)
            .sheet(isPresented: $searchPresented) {
                PlaceSearch(recent: recent, title: "Find timer destination") { select($0) }
                    .preferredColorScheme(theme)
            }
    }
    private func select(_ place: NamedPlace) {
        selected = place
        camera = .region(.init(center: place.point.coordinate, span: .init(latitudeDelta: 0.005, longitudeDelta: 0.005)))
    }

}

func timerText(_ seconds: TimeInterval) -> String {
    let value = Int(ceil(max(0, seconds)))
    return value >= 3600 ? String(format: "%d:%02d:%02d", value / 3600, value / 60 % 60, value % 60)
        : String(format: "%d:%02d", value / 60, value % 60)
}
