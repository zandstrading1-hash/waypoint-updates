import Foundation

struct RoutePoint: Equatable, Sendable {
    let latitude: Double
    let longitude: Double

    var valid: Bool {
        latitude.isFinite && longitude.isFinite && abs(latitude) <= 90 && abs(longitude) <= 180
    }

    func distance(to other: RoutePoint) -> Double {
        let p = latitude * .pi / 180, q = other.latitude * .pi / 180
        let a = sin((q - p) / 2)
        let b = sin((other.longitude - longitude) * .pi / 360)
        return 6_371_008.8 * 2 * asin(sqrt(min(1, max(0, a * a + cos(p) * cos(q) * b * b))))
    }
}

struct PhoneRoute {
    let points: [RoutePoint]
    let lengths: [Double]
    var total: Double { lengths.last ?? 0 }

    init(_ points: [RoutePoint]) throws {
        guard (2...20_000).contains(points.count), points.allSatisfy({ $0.valid }) else {
            throw PhoneFailure.message("Choose a valid route with at least two points.")
        }
        var lengths = [0.0]
        for index in 1..<points.count {
            lengths.append(lengths[index - 1] + points[index - 1].distance(to: points[index]))
        }
        guard let distance = lengths.last, (1...3_000_000).contains(distance) else {
            throw PhoneFailure.message("Choose a route between 1 meter and 3,000 km.")
        }
        self.points = points
        self.lengths = lengths
    }

    func at(_ meters: Double) -> RoutePoint {
        if meters >= total { return points.last! }
        let value = max(0, meters)
        var low = 0, high = lengths.count - 1
        while low + 1 < high {
            let mid = (low + high) / 2
            if lengths[mid] <= value { low = mid } else { high = mid }
        }
        let a = points[low], b = points[low + 1]
        let span = lengths[low + 1] - lengths[low]
        let fraction = span > 0 ? (value - lengths[low]) / span : 0
        let delta = (b.longitude - a.longitude + 540).truncatingRemainder(dividingBy: 360) - 180
        let longitude = (a.longitude + delta * fraction + 540).truncatingRemainder(dividingBy: 360) - 180
        return RoutePoint(latitude: a.latitude + (b.latitude - a.latitude) * fraction, longitude: longitude)
    }
}

enum PhoneFailure: LocalizedError {
    case message(String)
    var errorDescription: String? { if case .message(let message) = self { return message }; return nil }
}
