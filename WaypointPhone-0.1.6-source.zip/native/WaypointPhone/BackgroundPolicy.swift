// Pure policy so permission, foreground and Stop behavior can be checked without a phone.
enum BackgroundPolicy {
    enum Permission: Equatable { case notDetermined, allowed, denied }
    enum Action: Equatable { case stop, requestPermission, start, keepRunning, waitForForeground }

    static func action(enabled: Bool, sessionRunning: Bool, foreground: Bool,
                       permission: Permission, serviceRunning: Bool,
                       userRequestedPermission: Bool) -> Action {
        guard enabled else { return .stop }
        if permission == .notDetermined {
            return foreground && userRequestedPermission ? .requestPermission : .stop
        }
        guard permission == .allowed, sessionRunning else { return .stop }
        if serviceRunning { return .keepRunning }
        // When In Use services must start while the app is in the foreground.
        return foreground ? .start : .waitForForeground
    }
}
