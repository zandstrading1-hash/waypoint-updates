import SwiftUI
import MapKit

extension PhoneView {
    var mapView: some View {
        MapReader { proxy in
            Map(position: $position) {
                if let area, moveInside && !routeMode {
                    MapPolygon(coordinates: area.vertices.map(\.coordinate)).foregroundStyle(ink.opacity(0.18)).stroke(ink, lineWidth: 2)
                }
                if drawingArea {
                    if areaCorners.count >= 2 { MapPolyline(coordinates: areaCorners.map(\.coordinate)).stroke(.orange, lineWidth: 2) }
                    ForEach(Array(areaCorners.enumerated()), id: \.offset) { index, corner in
                        Annotation("Corner \(index + 1)", coordinate: corner.coordinate) {
                            Text("\(index + 1)").font(.caption2.bold()).padding(4).background(.orange, in: Circle())
                        }
                    }
                }
                if let start { Marker(routeMode ? "Draft start" : selectedPlace ?? "Selected place", coordinate: start.coordinate).tint(.orange) }
                if routeMode, let finish { Marker("Finish", coordinate: finish.coordinate).tint(.orange) }
                if let route { MapPolyline(coordinates: route.points.map(\.coordinate)).stroke(ink, lineWidth: 5) }
                if let current = session.point {
                    Marker(session.placeName, coordinate: current.coordinate).tint(ink)
                }
            }
            .onTapGesture { screenPoint in
                guard let coordinate = proxy.convert(screenPoint, from: .local) else { return }
                if drawingArea {
                    if areaCorners.count < 12 { areaCorners.append(RoutePoint(coordinate)); error = nil }
                    else { error = "Use up to 12 corners, then choose Use this area." }
                } else { select(RoutePoint(coordinate)) }
            }
            .mapStyle(satellite ? .imagery(elevation: .flat) : .standard(elevation: .flat))
            .mapControls { MapCompass(); MapScaleView() }
        }
    }

    var advancedPlanner: some View {
        VStack(alignment: .leading, spacing: 10) {
            if routeMode {
                Picker("Map selection", selection: $choosingFinish) {
                    Text("Tap start").tag(false); Text("Tap finish").tag(true)
                }.pickerStyle(.segmented)
                if let current = session.point {
                    Button("Use active location as start") { choosingFinish = false; select(current, label: "Active location") }
                }
                Button(planning ? "Calculating…" : "Calculate driving route") { Task { await calculateRoute() } }
                    .disabled(start == nil || finish == nil || planning)
                HStack { Text("Speed"); Spacer(); Text("\(Int(speed)) mph") }
                Slider(value: $speed, in: 1...85, step: 1)
                if let route { Text(String(format: "%.2f miles", route.total / 1609.344)).font(.caption) }
            } else { areaEditor }
        }.font(.subheadline)
    }

    var areaEditor: some View {
        VStack(alignment: .leading, spacing: 10) {
            if moveInside {
                Label("Continuous walking · 1 m/s", systemImage: "figure.walk").font(.subheadline.weight(.medium))
                Text("Moves without scheduled pauses inside your outline. Mark the area inside the building; walls and floors are not detected.").font(.footnote)
                if drawingArea {
                    Text("Tap 3–12 corners in order around the area. Avoid inward bends.").font(.footnote.weight(.medium))
                    HStack {
                        Button("Undo corner") { if !areaCorners.isEmpty { areaCorners.removeLast() } }.disabled(areaCorners.isEmpty)
                        Spacer()
                        Button("Use this area") { finishArea() }.disabled(areaCorners.count < 3)
                    }
                    Button("Cancel drawing") { drawingArea = false; areaCorners = []; error = nil }
                } else {
                    Button(area == nil ? "Draw movement area" : "Redraw area") {
                        area = nil; areaCorners = []; drawingArea = true; error = nil
                        planVersion = UUID()
                    }.disabled(start == nil || planning)
                    if let area {
                        Text(String(format: "%.0f m² · movement stays 2 m inside the outline", area.squareMeters)).font(.caption)
                    } else { Text("Search for the address, zoom in, then draw the area. Satellite view can help.").font(.caption) }
                }
            }
        }
    }

    func finishArea() {
        do {
            let approvedArea = try IndoorArea(areaCorners)
            area = approvedArea; start = approvedArea.center; drawingArea = false; error = nil
        } catch { self.error = error.localizedDescription }
    }

    func select(_ point: RoutePoint, label: String? = nil) {
        guard point.valid else { return }
        guard !drawingArea else { return }
        remember(point, name: label ?? "Dropped pin")
        error = nil; route = nil; planVersion = UUID()
        area = nil; areaCorners = []; selectedPlace = label
        if routeMode && choosingFinish { finish = point } else { start = point }
        if routeMode { choosingFinish.toggle() }
        let span = moveInside && !routeMode ? 0.0012 : 0.004
        position = .region(MKCoordinateRegion(center: point.coordinate, span: .init(latitudeDelta: span, longitudeDelta: span)))
    }

    func calculateRoute() async {
        guard !planning, let start, let finish else { return }
        planning = true; defer { planning = false }
        let version = planVersion
        do {
            let request = MKDirections.Request()
            request.source = MKMapItem(placemark: MKPlacemark(coordinate: start.coordinate))
            request.destination = MKMapItem(placemark: MKPlacemark(coordinate: finish.coordinate))
            request.transportType = .automobile
            let response = try await MKDirections(request: request).calculate()
            guard version == planVersion, let line = response.routes.first?.polyline else { return }
            var coordinates = [CLLocationCoordinate2D](repeating: .init(), count: line.pointCount)
            line.getCoordinates(&coordinates, range: NSRange(location: 0, length: line.pointCount))
            route = try PhoneRoute(coordinates.map(RoutePoint.init))
            position = .rect(line.boundingMapRect)
        } catch { if version == planVersion { self.error = "Could not calculate that driving route. Try endpoints closer to roads." } }
    }
}
