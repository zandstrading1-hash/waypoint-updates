import SwiftUI
import MapKit
import UniformTypeIdentifiers

enum PlanMode: String, CaseIterable { case hold = "Hold", drive = "Drive", area = "Area" }

struct PhoneView: View {
    @ObservedObject var session: PhoneSession
    @Environment(\.scenePhase) var scenePhase
    @Environment(\.dynamicTypeSize) var typeSize
    @Environment(\.colorScheme) var systemTheme
    @ScaledMetric(relativeTo: .largeTitle) var headingSize = 32
    @AppStorage("appearance") var appearance = "system"
    @State var position: MapCameraPosition = .region(.init(center: .init(latitude: 42.3384, longitude: -83.0245), span: .init(latitudeDelta: 0.06, longitudeDelta: 0.06)))
    @State var searchPresented = false
    @AppStorage("compactMap") var compactMap = false
    @AppStorage("showRecentPlaces") var showRecentPlaces = true
    @State var mode: PlanMode = .hold
    @State var drawingArea = false
    @State var areaCorners: [RoutePoint] = []
    @State var area: IndoorArea?
    @State var satellite = false
    @State var selectedPlace: String?
    @State var choosingFinish = false
    @State var start: RoutePoint?
    @State var finish: RoutePoint?
    @State var route: PhoneRoute?
    @State var speed = 25.0
    @State var importing = false
    @State var setup = false
    @State var options = false
    @State var planning = false
    @State var planVersion = UUID()
    @State var error: String?
    @State var page = 0
    @State var recent: [NamedPlace] = []
    @State var timerDraft = TimerDraft()
    @State var timerEditor: TimerSheet?

    struct TimerSheet: Identifiable {
        let id = UUID()
        let active: Bool
        let draft: TimerDraft
        var sessionID: UUID? = nil
    }
    var routeMode: Bool { mode == .drive }
    var moveInside: Bool { mode == .area }
    var ink: Color { .waypoint }
    var preferredTheme: ColorScheme? { appearance == "light" ? .light : appearance == "dark" ? .dark : nil }

    var body: some View {
        NavigationStack { presentedContent }
            // Update SwiftUI's semantic text colors immediately as well as the
            // window preference. Otherwise a restored theme can briefly leave
            // primary text using the previous appearance on the native map.
            .environment(\.colorScheme, preferredTheme ?? systemTheme)
            .tint(Color.waypoint)
            .preferredColorScheme(preferredTheme)
            .onAppear {
                reportVisibility()
                #if WAYPOINT_UI_PREVIEW
                seedPreview()
                #endif
            }
            .onChange(of: scenePhase) { _, _ in reportVisibility() }
            .onChange(of: mode) { _, _ in
                route = nil; area = nil; areaCorners = []; drawingArea = false
                choosingFinish = false; planVersion = UUID()
            }
    }

    var presentedContent: some View {
        contentWithSheets.fileImporter(isPresented: $importing, allowedContentTypes: [.data]) { result in
            do { try session.importPairing(result.get()) } catch { self.error = error.localizedDescription }
        }
    }
    var contentWithSheets: some View {
        tabs.sheet(isPresented: $searchPresented) {
            PlaceSearch(recent: recent) { place in select(place.point, label: place.name) }
                .preferredColorScheme(preferredTheme)
        }.sheet(isPresented: $setup) { setupView.preferredColorScheme(preferredTheme) }
            .sheet(isPresented: $options) {
                PhoneOptions(mode: $mode, appearance: $appearance, compactMap: $compactMap,
                             showRecentPlaces: $showRecentPlaces, satellite: $satellite,
                             canCenter: session.point != nil || start != nil,
                             center: { centerActive(); options = false }) { setupContent }
                    .preferredColorScheme(preferredTheme)
            }
            .sheet(item: $timerEditor) { item in
                TimerEditor(draft: item.draft, recent: recent) { updated in
                    if item.active {
                        if let expected = item.sessionID, !session.updateTimer(updated.plan, for: expected) {
                            error = "The session changed. Check Session before editing its timer."
                        }
                    } else { timerDraft = updated }
                }.preferredColorScheme(preferredTheme)
            }
    }
    var tabs: some View {
        TabView(selection: $page) {
            mapPage.tabItem { Label("Map", systemImage: "map.fill") }.tag(0)
            placesPage.tabItem { Label("Places", systemImage: "bookmark.fill") }.tag(1)
            sessionPage.tabItem { Label("Session", systemImage: "list.bullet.rectangle.fill") }.tag(2)
        }.toolbar(.hidden, for: .navigationBar)
    }

    var mapPage: some View {
        GeometryReader { geometry in
            VStack(spacing: 0) {
                mapHeader
                mapView.overlay(alignment: .topLeading) {
                    if session.active || session.needsRestore { sessionBadge.padding(16) }
                }.overlay(alignment: .bottomTrailing) { mapTools.padding(14) }
                    .frame(minHeight: 150, maxHeight: .infinity)
                ScrollView {
                    draftPanel
                }.frame(maxHeight: typeSize.isAccessibilitySize ? geometry.size.height * 0.53 : mode == .hold ? (timerDraft.minutes > 0 ? 245 : 205) : 330)
                    .background(Color.waypointSurface)
                restoreControls.padding(.horizontal, 20).padding(.bottom, 6)
            }.background(Color.waypointSurface)
        }
    }

    var mapHeader: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Waypoint").font(.system(size: headingSize, weight: .bold)).foregroundStyle(ink)
                Spacer()
                if compactMap {
                    Button { searchPresented = true } label: {
                        Image(systemName: "magnifyingglass").frame(width: 44, height: 44)
                    }.accessibilityLabel("Find a place").accessibilityIdentifier("openSearch").disabled(drawingArea)
                }
                Button { options = true } label: {
                    Image(systemName: "slider.horizontal.3").font(.title2).frame(width: 44, height: 44)
                }
                    .accessibilityLabel("More options")
            }
            if !compactMap { searchBar }
            if showRecentPlaces { recentStrip }
        }.padding(.horizontal, 20).padding(.top, 4).padding(.bottom, 10)
    }

    var searchBar: some View {
        Button { searchPresented = true } label: {
            HStack(spacing: 10) {
                Image(systemName: "magnifyingglass").foregroundStyle(ink)
                Text("Find a place or address").foregroundStyle(.primary)
                Spacer(minLength: 0)
            }.font(.body).padding(.horizontal, 14).frame(minHeight: 50)
                .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 14))
        }.buttonStyle(.plain).disabled(drawingArea).accessibilityIdentifier("openSearch")
    }

    var recentStrip: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 18) {
                Button { page = 1 } label: { Label("Recent", systemImage: "clock.arrow.circlepath") }
                if recent.isEmpty { Text("Your places appear here").foregroundStyle(.secondary) }
                ForEach(recent.prefix(4)) { place in
                    Button { useRecent(place) } label: { Label(place.name, systemImage: "mappin") }
                        .lineLimit(1)
                }
            }.font(.subheadline).frame(minHeight: 34)
        }
    }

    var draftPanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            if let error { Text(error).font(.footnote).foregroundStyle(.red) }
            HStack(alignment: .center, spacing: 12) {
                Image(systemName: "mappin.circle.fill").font(.system(size: 36)).foregroundStyle(.orange)
                VStack(alignment: .leading, spacing: 3) {
                    Text(mode == .hold ? "Selected place" : mode.rawValue + " plan").font(.caption).foregroundStyle(.secondary)
                    Text(selectedPlace ?? (start == nil ? "Choose a place" : "Dropped pin"))
                        .font(.title3.bold()).lineLimit(2).accessibilityIdentifier("selectedPlace")
                    Text(mode == .hold ? "Instant switch · No route" : mode == .drive ? "Follow a driving route" : "Move inside your outline")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Spacer(minLength: 0)
            }
            if mode != .hold { advancedPlanner }
            TimerPresets(draft: $timerDraft) { timerEditor = .init(active: false, draft: timerDraft) }
            if timerDraft.minutes > 0 {
                Button { timerEditor = .init(active: false, draft: timerDraft) } label: {
                    HStack(spacing: 10) {
                        Image(systemName: "arrow.turn.up.right"); Text("Then"); Spacer()
                        Text(timerDraft.ending.title).lineLimit(2)
                        Image(systemName: "chevron.right").font(.caption)
                    }.font(.subheadline).padding(.vertical, 4)
                }.buttonStyle(.plain)
            }
            Button(startLabel) { applyPlan(replacing: session.canReplace) }
                .buttonStyle(WaypointButton())
                .disabled(!session.pairingReady || !draftReady || !(session.canEdit || session.canReplace))
            if !session.pairingReady { Button("Finish phone setup") { setup = true }.frame(maxWidth: .infinity) }
        }.padding(.horizontal, 20).padding(.vertical, 14)
    }

    var sessionBadge: some View {
        Button { page = 2 } label: {
            HStack(spacing: 10) {
                Image(systemName: "clock").font(.title2).foregroundStyle(ink)
                VStack(alignment: .leading, spacing: 2) {
                    Text("\(session.phase.replacingOccurrences(of: "-", with: " ").capitalized) · \(session.placeName)")
                        .font(.caption.bold()).lineLimit(1)
                    TimelineView(.periodic(from: .now, by: 1)) { _ in
                        Text(session.timerRemaining.map { timerText($0) + " left" } ?? (session.holdTimer.plan != nil ? "Timer starts when connected" : session.needsRestore && !session.active ? "Check restoration" : "Until you stop"))
                            .font(.caption).monospacedDigit().foregroundStyle(ink)
                    }
                }
            }.padding(12).background(Color.waypointSurface, in: Capsule())
        }.buttonStyle(.plain).frame(maxWidth: 300, alignment: .leading)
    }

    var mapTools: some View {
        VStack(spacing: 8) {
            if drawingArea {
                Button("Use area") { finishArea() }.buttonStyle(.borderedProminent).disabled(areaCorners.count < 3)
                Button("Undo") { if !areaCorners.isEmpty { areaCorners.removeLast() } }.buttonStyle(.bordered)
            }
            Button { centerActive() } label: {
                Image(systemName: "location.fill").font(.title3).frame(width: 44, height: 44)
                    .background(Color.waypointSurface, in: Circle())
            }.accessibilityLabel("Center map on active or selected location")
        }
    }

    var placesPage: some View {
        List {
            Section {
                Text("Recent places").font(.largeTitle.bold())
                Text("Choose a place to preview it on the map. Switching requires tapping Switch here now.")
                    .font(.subheadline).foregroundStyle(.secondary)
            }.listRowSeparator(.hidden)
            if recent.isEmpty {
                ContentUnavailableView("No recent places", systemImage: "bookmark", description: Text("Search or tap the map to add a place."))
            }
            ForEach(recent) { place in
                Button { useRecent(place); page = 0 } label: {
                    Label(place.name, systemImage: "mappin.circle").padding(.vertical, 8)
                }
            }.onDelete { recent.remove(atOffsets: $0) }
            Section {
                Button("Find a place") { page = 0; searchPresented = true }
                if !recent.isEmpty { Button("Clear recent places", role: .destructive) { recent = [] } }
                Text("Recent places stay in memory for this app session. They are not saved or uploaded.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }.listStyle(.plain)
    }

    var restoreControls: some View {
        VStack(spacing: 10) {
            if session.active || session.needsRestore {
                Button(session.phase == "stopping" ? "Restoring…" : "Stop & restore") { session.stop() }
                    .font(.subheadline.bold()).frame(maxWidth: .infinity, minHeight: 32)
                    .disabled(session.phase == "stopping")
            }
            if (session.phase == "idle" || session.phase == "restore-needed") && session.needsRestore {
                Text(session.message).font(.footnote).foregroundStyle(.secondary)
                Button("I checked: normal location is restored") { session.confirmRestored() }.font(.footnote)
            }
        }
    }

    var startLabel: String {
        if routeMode { return session.canReplace ? "Apply driving route" : "Start driving" }
        if moveInside { return session.canReplace ? "Apply area movement" : "Start area movement" }
        return session.canReplace ? "Switch here now" : "Hold here"
    }
    var draftReady: Bool {
        !planning && !drawingArea && (routeMode ? route != nil : start != nil && (!moveInside || area != nil))
    }
    func applyPlan(replacing: Bool) {
        guard draftReady else { error = "Finish choosing your place, route, or area."; return }
        searchPresented = false; error = nil
        if !session.start(point: start, route: routeMode ? route : nil, speed: speed,
                         area: moveInside ? area : nil, replacing: replacing,
                         name: selectedPlace ?? "Dropped pin", timer: timerDraft.plan) {
            error = session.message
        }
    }
    func reportVisibility() { session.visibilityChanged(foreground: scenePhase == .active, enteredBackground: scenePhase == .background) }
    func centerActive() {
        guard let point = session.point ?? start else { return }
        position = .region(.init(center: point.coordinate, span: .init(latitudeDelta: 0.005, longitudeDelta: 0.005)))
    }
    func useRecent(_ place: NamedPlace) { select(place.point, label: place.name) }
    func remember(_ point: RoutePoint, name: String) {
        recent.removeAll { $0.point == point }
        recent.insert(NamedPlace(name: name, point: point), at: 0)
        recent = Array(recent.prefix(12))
    }
    #if WAYPOINT_UI_PREVIEW
    func seedPreview() {
        guard recent.isEmpty else { return }
        appearance = ProcessInfo.processInfo.arguments.contains("--preview-dark") ? "dark" : "light"
        let library = NamedPlace(name: "City Library", point: .init(latitude: 42.3344, longitude: -83.041))
        let square = NamedPlace(name: "Town Square", point: .init(latitude: 42.3315, longitude: -83.047))
        compactMap = false; showRecentPlaces = true
        recent = [library, square]; start = library.point; selectedPlace = library.name
        timerDraft = TimerDraft(minutes: 30, ending: .switchTo(square))
        position = .region(.init(center: .init(latitude: 42.332, longitude: -83.043), span: .init(latitudeDelta: 0.012, longitudeDelta: 0.012)))
        if ProcessInfo.processInfo.arguments.contains("--preview-session") { page = 2 }
        if ProcessInfo.processInfo.arguments.contains("--preview-timer") { timerEditor = .init(active: false, draft: timerDraft) }
    }
    #endif
}
