func runBackgroundChecks() {
    typealias Policy = BackgroundPolicy
    // Starting in the foreground with When In Use access must run the service;
    // the previous implementation asked for Always and never started it.
    precondition(Policy.action(enabled: true, sessionRunning: true, foreground: true,
        permission: .allowed, serviceRunning: false, userRequestedPermission: false) == .start)
    // Switching apps must retain an already started service.
    precondition(Policy.action(enabled: true, sessionRunning: true, foreground: false,
        permission: .allowed, serviceRunning: true, userRequestedPermission: false) == .keepRunning)
    // A suspended/lost service cannot newly start in the background.
    precondition(Policy.action(enabled: true, sessionRunning: true, foreground: false,
        permission: .allowed, serviceRunning: false, userRequestedPermission: false) == .waitForForeground)
    // Saved opt-in never starts a service on launch or after Stop/restore.
    for foreground in [false, true] {
        for permission in [Policy.Permission.notDetermined, .allowed, .denied] {
            precondition(Policy.action(enabled: true, sessionRunning: false, foreground: foreground,
                permission: permission, serviceRunning: true, userRequestedPermission: false) == .stop)
            precondition(Policy.action(enabled: false, sessionRunning: true, foreground: foreground,
                permission: permission, serviceRunning: true, userRequestedPermission: true) == .stop)
        }
    }
    precondition(Policy.action(enabled: true, sessionRunning: true, foreground: true,
        permission: .denied, serviceRunning: true, userRequestedPermission: true) == .stop)
    // Permission requests require a foreground user action, including before Start.
    precondition(Policy.action(enabled: true, sessionRunning: false, foreground: true,
        permission: .notDetermined, serviceRunning: false, userRequestedPermission: true) == .requestPermission)
    precondition(Policy.action(enabled: true, sessionRunning: true, foreground: false,
        permission: .notDetermined, serviceRunning: false, userRequestedPermission: true) == .stop)
    precondition(Policy.action(enabled: true, sessionRunning: true, foreground: true,
        permission: .notDetermined, serviceRunning: false, userRequestedPermission: false) == .stop)
    print("Background permission/lifecycle policy checks passed (not iOS runtime evidence).")
}
