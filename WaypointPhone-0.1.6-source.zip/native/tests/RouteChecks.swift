import Foundation

@main
struct RouteChecks {
    static func main() async throws {
        let route = try PhoneRoute([.init(latitude: 0, longitude: 0), .init(latitude: 0, longitude: 0), .init(latitude: 0, longitude: 0.01)])
        precondition(abs(route.total - 1111.95) < 0.1)
        precondition(abs(route.at(route.total / 2).longitude - 0.005) < 0.000001)
        precondition(route.at(route.total + 1).longitude == 0.01)
        let across = try PhoneRoute([.init(latitude: 0, longitude: 179.99), .init(latitude: 0, longitude: -179.99)])
        precondition(abs(abs(across.at(across.total / 2).longitude) - 180) < 0.000001)
        do {
            _ = try PhoneRoute([.init(latitude: .nan, longitude: 0), .init(latitude: 0, longitude: 1)])
            preconditionFailure("Invalid coordinates were accepted")
        } catch is PhoneFailure {}
        try runIndoorChecks()
        runBackgroundChecks()
        await runPlaybackChecks()
        await runTimerChecks()
        await runConnectionChecks()
        print("Native route checks passed (math only; no device integration tested).")
    }
}
