import Foundation

// Deliberately ignores cancellation, like an in-flight synchronous native call.
@MainActor
private final class BlockedCommand {
    private var completion: CheckedContinuation<Void, Never>?
    private var started: CheckedContinuation<Void, Never>?
    private var entered = false
    func send() async {
        await withCheckedContinuation { continuation in
            completion = continuation
            entered = true
            started?.resume(); started = nil
        }
    }
    func waitUntilStarted() async {
        if entered { return }
        await withCheckedContinuation { started = $0 }
    }
    func finish() { completion?.resume(); completion = nil }
}

@MainActor
func runPlaybackChecks() async {
    let playback = SessionPlayback()
    let oldCommand = BlockedCommand()
    let newCommand = BlockedCommand()
    var published: [String] = []
    var writesAfterCancellation = 0
    let old = playback.start { token in
        await oldCommand.send()
        guard playback.accepts(token) else { return }
        published.append("old")
        writesAfterCancellation += 1
    }
    await oldCommand.waitUntilStarted()
    let replacement = playback.start { token in
        await newCommand.send()
        guard playback.accepts(token) else { return }
        published.append("replacement")
    }
    await newCommand.waitUntilStarted()
    oldCommand.finish()
    await old.value
    precondition(published.isEmpty && writesAfterCancellation == 0,
                 "A replaced in-flight command must not publish or continue playback")
    newCommand.finish()
    await replacement.value
    precondition(published == ["replacement"])

    let stoppingCommand = BlockedCommand()
    let stopping = playback.start { token in
        await stoppingCommand.send()
        guard playback.accepts(token) else { return }
        writesAfterCancellation += 1
    }
    await stoppingCommand.waitUntilStarted()
    playback.cancel() // Production does this BEFORE queuing restore.
    stoppingCommand.finish()
    await stopping.value
    precondition(writesAfterCancellation == 0, "Stop must retire even an uncancellable command")
    playback.cancel() // Repeated cancellation stays harmless.

    for phase in ["idle", "starting", "recovering", "stopping", "restore-needed", "unknown"] {
        precondition(!SessionPlayback.canReplace(phase: phase))
    }
    for phase in ["holding", "driving", "wandering", "paused", "arrived"] {
        precondition(SessionPlayback.canReplace(phase: phase))
    }
    print("Playback replacement/cancellation checks passed (controlled commands, not native transport evidence).")
}
