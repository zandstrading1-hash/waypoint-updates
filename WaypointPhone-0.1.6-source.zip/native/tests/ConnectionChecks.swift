import Foundation

@MainActor
func runConnectionChecks() async {
    var replies: [@Sendable (ConnectionCheck.Outcome) -> Void] = []
    var cancelled = 0
    let check = ConnectionCheck(timeout: .milliseconds(100)) { reply in
        replies.append(reply)
        return { cancelled += 1 }
    }
    check.run()
    precondition(check.running && check.outcome == nil)
    replies[0](.reachable)
    try? await Task.sleep(for: .milliseconds(20))
    precondition(check.outcome == .reachable && !check.running && cancelled == 1)
    check.run(); check.cancel()
    replies[1](.refused)
    try? await Task.sleep(for: .milliseconds(20))
    precondition(check.outcome == nil && !check.running && cancelled == 2)
    check.run()
    replies[1](.reachable) // A prior connection must not finish the new check.
    try? await Task.sleep(for: .milliseconds(20))
    precondition(check.running && check.outcome == nil)
    replies[2](.refused)
    try? await Task.sleep(for: .milliseconds(20))
    precondition(check.outcome == .refused && cancelled == 3)
    check.run()
    try? await Task.sleep(for: .milliseconds(200))
    precondition(check.outcome == .timedOut && !check.running && cancelled == 4)
    replies[3](.reachable)
    try? await Task.sleep(for: .milliseconds(20))
    precondition(check.outcome == .timedOut && cancelled == 4)
    check.run(); check.run()
    replies[4](.unavailable)
    try? await Task.sleep(for: .milliseconds(20))
    precondition(check.running && check.outcome == nil && cancelled == 5)
    check.cancel()
    precondition(cancelled == 6)
    print("Connection check lifecycle passed; fake TCP driver, no phone commands.")
}
