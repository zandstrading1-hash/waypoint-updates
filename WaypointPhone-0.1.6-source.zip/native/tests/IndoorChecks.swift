import Foundation

func runIndoorChecks() throws {
    let metersPerDegree = 6_371_008.8 * Double.pi / 180
    func point(_ x: Double, _ y: Double, latitude: Double = 42, longitude: Double = -83) -> RoutePoint {
        let lon = longitude + x / (metersPerDegree * cos(latitude * .pi / 180))
        return .init(latitude: latitude + y / metersPerDegree,
                     longitude: lon > 180 ? lon - 360 : lon)
    }
    func reject(_ corners: [RoutePoint]) {
        do { _ = try IndoorArea(corners); preconditionFailure("Invalid boundary was accepted") }
        catch is PhoneFailure {} catch { preconditionFailure("Unexpected error: \(error)") }
    }
    reject([point(0, 0), point(30, 0)])
    reject([point(0, 0), point(30, 0), point(30, 30), point(10, 10), point(0, 30)])
    reject([point(0, 0), point(30, 30), point(30, 0), point(0, 30)])
    reject([point(0, 0), point(3, 0), point(3, 30), point(0, 30)])
    reject([point(0, 0), point(30, 0), point(30, 30), point(30, 30), point(0, 30)])
    reject([point(0, 0), point(900, 0), point(900, 30), point(0, 30)])
    reject([point(0, 0), .init(latitude: .nan, longitude: 0), point(0, 30)])

    // Independent rectangular bounds, including reverse winding, high latitude,
    // and crossing +180/-180. Check 300,000 steps, not only chosen destinations.
    for (latitude, longitude, reversed) in [(42.0, -83.0, false), (70.0, 20.0, true), (10.0, 179.9999, false)] {
        let corners = [point(0, 0, latitude: latitude, longitude: longitude),
                       point(40, 0, latitude: latitude, longitude: longitude),
                       point(40, 30, latitude: latitude, longitude: longitude),
                       point(0, 30, latitude: latitude, longitude: longitude)]
        let area = try IndoorArea(reversed ? Array(corners.reversed()) : corners)
        var motion = IndoorMotion(area: area, seed: 42)
        var moving = 0, stationary = 0
        for _ in 0..<100_000 {
            let before = motion.point
            let next = motion.advance(seconds: 0.25)
            let dy = (next.latitude - latitude) * metersPerDegree
            var deltaLongitude = next.longitude - longitude
            if deltaLongitude < -180 { deltaLongitude += 360 }
            let dx = deltaLongitude * metersPerDegree * cos(latitude * .pi / 180)
            precondition(dx >= 1.999 && dx <= 38.001 && dy >= 1.999 && dy <= 28.001)
            precondition(area.contains(next, inset: IndoorArea.margin))
            let traveled = before.distance(to: next)
            precondition(traveled <= 0.251, "Movement exceeded walking-speed bound")
            if traveled > 0.000001 { moving += 1 } else { stationary += 1 }
        }
        precondition(moving == 100_000 && stationary == 0, "Continuous movement must not insert stationary frames")
        let beforeDelay = motion
        for delay in [600.0, -1.0, .nan, .infinity, 0.0] {
            precondition(motion.advance(seconds: delay) == beforeDelay.point)
        }
        var reference = beforeDelay
        precondition(motion.advance(seconds: 0.25) == reference.advance(seconds: 0.25), "A skipped frame changed playback")
    }

    let triangle = try IndoorArea([point(0, 0), point(50, 0), point(5, 35)])
    var triangularMotion = IndoorMotion(area: triangle, seed: 23)
    for _ in 0..<10_000 { precondition(triangle.contains(triangularMotion.advance(seconds: 1), inset: 2)) }
    var alternate = IndoorMotion(area: triangle, seed: 24)
    var initial = IndoorMotion(area: triangle, seed: 23)
    precondition(alternate.advance(seconds: 1) != initial.advance(seconds: 1))
    // Smallest square with a usable inset exercises short segments and fallback.
    let small = try IndoorArea([point(0, 0), point(6.1, 0), point(6.1, 6.1), point(0, 6.1)])
    for seed in UInt64(0)..<50 {
        var motion = IndoorMotion(area: small, seed: seed)
        var distance = 0.0
        for _ in 0..<240 {
            let previous = motion.point
            let next = motion.advance(seconds: 0.25)
            precondition(small.contains(next, inset: 2))
            let step = previous.distance(to: next)
            precondition(step > 0.000001 && step <= 0.251)
            distance += step
        }
        precondition(distance > 40, "One minute of movement should not contain long waits")
    }
    print("Indoor checks passed: 322,000 bounded continuous movement steps, small outlines, speed limits, invalid outlines, and no delayed-frame catch-up. Geometry only; no phone or building survey tested.")
}
