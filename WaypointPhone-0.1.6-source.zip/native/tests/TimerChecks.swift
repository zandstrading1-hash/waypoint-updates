import Foundation

@MainActor
private final class TimerCommand {
    var completion: CheckedContinuation<Void, Never>?
    var started: CheckedContinuation<Void, Never>?
    var entered = false
    func run() async {
        await withCheckedContinuation {
            completion = $0; entered = true; started?.resume(); started = nil
        }
    }
    func wait() async {
        if entered { return }
        await withCheckedContinuation { started = $0 }
    }
    func finish() { completion?.resume(); completion = nil }
}

@MainActor
func runTimerChecks() async {
    let destination = NamedPlace(name: "Test destination", point: .init(latitude: 0, longitude: 1))
    let restore = HoldTimerPlan(seconds: 60, ending: .restore)
    let move = HoldTimerPlan(seconds: 90, ending: .switchTo(destination))
    for seconds in [0, -1, .nan, .infinity, 86_401] {
        precondition(!HoldTimerPlan(seconds: seconds, ending: .restore).valid)
    }
    precondition(!HoldTimerPlan(seconds: 60, ending: .switchTo(.init(name: "Invalid", point: .init(latitude: 91, longitude: 0)))).valid)
    precondition(HoldTimerPlan(seconds: 86_400, ending: .restore).valid)
    var timer = HoldTimer()
    precondition(timer.plan == nil && timer.deadline == nil, "A fresh launch must not replay a timer")
    timer.prepare(restore)
    precondition(timer.takeDue(at: 10_000) == nil, "Connection delays must not consume an unstarted hold")
    timer.acknowledge(at: 100)
    precondition(timer.remaining(at: 130) == 30)
    timer.acknowledge(at: 150) // Reconnect: keep the original deadline.
    precondition(timer.deadline == 160)
    precondition(timer.takeDue(at: 159.999) == nil)
    precondition(timer.takeDue(at: 160) == .restore)
    precondition(timer.takeDue(at: 161) == nil, "Expiry must fire exactly once")

    timer.prepare(move); timer.acknowledge(at: 200)
    precondition(timer.takeDue(at: 9_000) == .switchTo(destination), "Missed deadlines must run on resume before old-location writes")
    precondition(timer.takeDue(at: 9_001) == nil)
    timer.prepare(restore); timer.acknowledge(at: 0)
    precondition(timer.extend(by: 900, at: 20))
    precondition(timer.takeDue(at: 60) == nil && timer.remaining(at: 60) == 900)
    precondition(!timer.extend(by: .infinity, at: 60))
    precondition(!timer.extend(by: 86_400, at: 60))
    precondition(!timer.extend(by: -10, at: 60))
    precondition(!timer.extend(by: 60, at: 960), "Extension must not resurrect an expired timer")
    precondition(timer.takeDue(at: 960) == .restore)
    timer.prepare(restore); timer.acknowledge(at: 0); timer.cancel()
    precondition(timer.takeDue(at: 100) == nil)
    timer.prepare(restore); timer.acknowledge(at: 0)
    timer.prepare(move) // Replacement cancels the old deadline and awaits new ack.
    precondition(timer.takeDue(at: 100) == nil)
    timer.acknowledge(at: 110)
    precondition(timer.takeDue(at: 200) == .switchTo(destination))

    // Exercise the same owner boundary as PhoneSession with an uncancellable
    // command: expiry retires the owner BEFORE restore/switch is queued.
    for ending in [HoldEnding.restore, .switchTo(destination)] {
        let playback = SessionPlayback()
        let blocked = TimerCommand()
        var state = HoldTimer()
        state.prepare(.init(seconds: 10, ending: ending)); state.acknowledge(at: 0)
        var oldWrites = 0
        var events: [HoldEnding] = []
        let old = playback.start { token in
            await blocked.run()
            guard playback.accepts(token) else { return }
            state.acknowledge(at: 30)
            oldWrites += 1
        }
        await blocked.wait()
        let editingSession = playback.identity
        if let action = state.takeDue(at: 20) {
            playback.cancel()
            events.append(action)
        }
        // A new hold begins while the old native acknowledgement is pending.
        precondition(playback.identity != editingSession, "An editor for a retired hold must not match the new session")
        state.prepare(move)
        blocked.finish(); await old.value
        precondition(oldWrites == 0 && state.deadline == nil,
                     "A retired acknowledgement must not arm a replacement timer")
        precondition(events == [ending])
        state.acknowledge(at: 40)
        precondition(state.deadline == 130)
        playback.cancel(); state.cancel()
        precondition(state.takeDue(at: 200) == nil)
    }
    print("Hold timer checks passed (deadlines, both endings, reconnect, extension, cancellation and blocked-command ownership; not iOS execution evidence).")
}
