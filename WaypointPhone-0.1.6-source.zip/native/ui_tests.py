"""Add an isolated UI test runner to the generated simulator project only."""
import hashlib
import json
from pathlib import Path


def configure(project: Path, tests: Path):
    ident = lambda name: hashlib.sha256(name.encode()).hexdigest()[:24].upper()
    objects = []

    def add(name, body):
        key = ident(name)
        objects.append(f"{key} = {{ {body} }};")
        return key

    file = add("uitest-file", f'isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = {json.dumps(tests.as_posix())}; sourceTree = "<absolute>";')
    compile = add("uitest-compile", f"isa = PBXBuildFile; fileRef = {file};")
    sources = add("uitest-sources", f"isa = PBXSourcesBuildPhase; buildActionMask = 2147483647; files = ({compile},); runOnlyForDeploymentPostprocessing = 0;")
    product = add("uitest-product", 'isa = PBXFileReference; explicitFileType = wrapper.cfbundle; path = SearchUITests.xctest; sourceTree = BUILT_PRODUCTS_DIR;')
    config = add("uitest-config", '''isa = XCBuildConfiguration; name = Release; buildSettings = {
        PRODUCT_NAME = SearchUITests; PRODUCT_BUNDLE_IDENTIFIER = com.zandstrading.waypoint.uitests;
        SDKROOT = iphonesimulator; SUPPORTED_PLATFORMS = iphonesimulator; ARCHS = arm64;
        IPHONEOS_DEPLOYMENT_TARGET = 17.4; SWIFT_VERSION = 6.0;
        GENERATE_INFOPLIST_FILE = YES; CODE_SIGNING_ALLOWED = NO; CODE_SIGNING_REQUIRED = NO;
        TEST_TARGET_NAME = WaypointPhone; TARGETED_DEVICE_FAMILY = 1;
        LD_RUNPATH_SEARCH_PATHS = ("$(inherited)", "@executable_path/Frameworks", "@loader_path/Frameworks",);
    };''')
    configs = add("uitest-configs", f"isa = XCConfigurationList; buildConfigurations = ({config},); defaultConfigurationIsVisible = 0; defaultConfigurationName = Release;")
    proxy = add("uitest-proxy", f'isa = PBXContainerItemProxy; containerPortal = {ident("project")}; proxyType = 1; remoteGlobalIDString = {ident("target")}; remoteInfo = WaypointPhone;')
    dependency = add("uitest-dependency", f'isa = PBXTargetDependency; target = {ident("target")}; targetProxy = {proxy};')
    target = add("uitest-target", f'isa = PBXNativeTarget; name = SearchUITests; productName = SearchUITests; productType = "com.apple.product-type.bundle.ui-testing"; productReference = {product}; buildConfigurationList = {configs}; buildPhases = ({sources},); buildRules = (); dependencies = ({dependency},);')
    pbx = project / "project.pbxproj"
    text = pbx.read_text()
    text = text.replace('objects = {\n', 'objects = {\n' + '\n'.join(objects) + '\n', 1)
    text = text.replace(f'targets = ({ident("target")},);', f'targets = ({ident("target")},{target},);')
    pbx.write_text(text)
    scheme = project / "xcshareddata/xcschemes/WaypointPhone.xcscheme"
    text = scheme.read_text()
    ref = f'<BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target}" BuildableName="SearchUITests.xctest" BlueprintName="SearchUITests" ReferencedContainer="container:WaypointPhone.xcodeproj"/>'
    text = text.replace('</BuildActionEntries>', f'<BuildActionEntry buildForTesting="YES" buildForRunning="NO" buildForProfiling="NO" buildForArchiving="NO" buildForAnalyzing="NO">{ref}</BuildActionEntry></BuildActionEntries>')
    text = text.replace('<LaunchAction ', f'<TestAction buildConfiguration="Release" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB"><Testables><TestableReference skipped="NO">{ref}</TestableReference></Testables></TestAction>\n<LaunchAction ')
    scheme.write_text(text)
