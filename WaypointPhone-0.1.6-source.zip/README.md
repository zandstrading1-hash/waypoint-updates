# Waypoint 0.1.6 (8) corresponding source

Source revision: 2d494e655959e75886211ad49d1adc329bbe99e8

On macOS with Xcode and Python 3: run `python3 native/build.py`. The script retrieves three pinned, checksum-verified idevice artifacts from StikDebug, runs the Swift checks, and builds an unsigned iPhone IPA. On Windows `python native/build.py --prepare` only prepares a project. Personal signing happens separately on the phone; no credentials are supplied.

Runtime: LocalDevVPN and an imported remote-pairing record for your own phone. No pairing records, signatures, private logs, or user coordinates are distributed. Cellular startup and restoration are not reliable. See native/THIRD_PARTY.md and native/LICENSE for attribution and AGPL-3.0 terms.
