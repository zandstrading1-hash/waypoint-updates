import Foundation
import Combine
import CoreLocation
import UIKit

@MainActor
final class PhoneSession: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published private(set) var phase = "idle"
    @Published private(set) var point: RoutePoint?
    @Published private(set) var message = "Experimental phone-only build. Start with a short supervised test."
    @Published private(set) var sentAt: Date?
    @Published private(set) var pairingReady = false
    @Published private(set) var needsRestore = UserDefaults.standard.bool(forKey: "needsRestore")
    @Published private(set) var retryCount = 0
    @Published private(set) var meters = 0.0
    @Published private(set) var backgroundRunning = false
    @Published private(set) var backgroundStatus = "Keep Waypoint open. Background holding is off."
    @Published private(set) var commandGaps = 0
    @Published private(set) var longestCommandGap = 0.0
    @Published private(set) var backgroundDiagnostic = "No background session requested."
    @Published private(set) var backgroundCommands = 0
    @Published private(set) var locationCallbacks = 0
    @Published private(set) var visibility = "Foreground"
    @Published private(set) var placeName = "Selected location"
    @Published private(set) var holdTimer = HoldTimer()
    @Published var backgroundHolding = UserDefaults.standard.bool(forKey: "backgroundHolding") {
        didSet {
            UserDefaults.standard.set(backgroundHolding, forKey: "backgroundHolding")
            updateBackgroundPermission(userRequestedPermission: backgroundHolding)
        }
    }
    private let manager = CLLocationManager()
    private let playback = SessionPlayback()
    private var timerTask: Task<Void, Never>?
    private let timerOrigin = ContinuousClock.now
    private var backgroundActivity: CLBackgroundActivitySession?
    private var diagnosticsTask: Task<Void, Never>?
    private var backgroundGeneration = UUID()
    private var route: PhoneRoute?
    private var indoorMotion: IndoorMotion?
    private var speed = 25.0
    private var routeClock = ProcessInfo.processInfo.systemUptime
    private var lastCommandTick: TimeInterval?
    private var foreground = true
    private var requestingPermission = false
    private let pairingURL: URL
    private lazy var bridge = DeviceBridge(pairingURL: pairingURL)
    var active: Bool { phase != "idle" }
    var canEdit: Bool { !active && !needsRestore }
    var canReplace: Bool { SessionPlayback.canReplace(phase: phase) }
    var sessionID: UUID { playback.identity }

    override init() {
        pairingURL = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("WaypointPrivate", isDirectory: true).appendingPathComponent("remote-pairing.plist")
        super.init()
        pairingReady = FileManager.default.fileExists(atPath: pairingURL.path)
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        manager.distanceFilter = kCLDistanceFilterNone
        manager.pausesLocationUpdatesAutomatically = false
        manager.allowsBackgroundLocationUpdates = true
        manager.showsBackgroundLocationIndicator = true
        updateBackgroundPermission()
        if needsRestore { message = "An earlier session may still affect location. Retry restore and verify the phone before starting." }
        #if WAYPOINT_UI_PREVIEW
        // Only the isolated simulator harness defines this flag and substitutes
        // a no-device bridge. Never enabled in the distributed iPhone archive.
        pairingReady = true; phase = "holding"; placeName = "Riverfront Park"
        point = RoutePoint(latitude: 42.3299, longitude: -83.0444)
        holdTimer.prepare(.init(seconds: 1500, ending: .restore))
        holdTimer.acknowledge(at: timerNow)
        message = "Simulator UI fixture. No physical device is connected."
        if ProcessInfo.processInfo.arguments.contains("--preview-connection-check") {
            phase = "idle"; needsRestore = false; point = nil; holdTimer.cancel()
        }
        if ProcessInfo.processInfo.arguments.contains(where: { $0.hasPrefix("--preview-consent") }) {
            phase = "idle"; point = nil; holdTimer.cancel()
            needsRestore = ProcessInfo.processInfo.arguments.contains("--preview-consent-restore")
        }
        #endif
    }

    func importPairing(_ url: URL) throws {
        guard canEdit else { throw PhoneFailure.message("Stop and confirm restoration before replacing pairing data.") }
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        let data = try Data(contentsOf: url, options: .mappedIfSafe)
        guard data.count <= 1_000_000,
              let values = try PropertyListSerialization.propertyList(from: data, format: nil) as? [String: Any],
              values["public_key"] != nil else {
            throw PhoneFailure.message("Choose a remote-pairing plist generated for this phone. Classic USB pairing files are different.")
        }
        var folder = pairingURL.deletingLastPathComponent()
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        var flags = URLResourceValues(); flags.isExcludedFromBackup = true
        try folder.setResourceValues(flags)
        try data.write(to: pairingURL, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        pairingReady = true
        message = "Pairing file stored on this phone. Enable LocalDevVPN and prepare the developer image before the first test."
    }

    @discardableResult
    func start(point: RoutePoint?, route: PhoneRoute?, speed: Double, area: IndoorArea? = nil,
               replacing: Bool = false, name: String = "Selected location", timer: HoldTimerPlan? = nil) -> Bool {
        guard (replacing ? canReplace : canEdit), pairingReady, speed.isFinite, (1...85).contains(speed),
              !(route != nil && area != nil),
              let first = area?.center ?? route?.at(0) ?? point, first.valid,
              timer == nil || timer!.valid else {
            message = "Import pairing data, finish any pending restoration, and choose a valid point or route."
            return false
        }
        guard UIApplication.shared.applicationState == .active else {
            message = "Open Waypoint before starting a session."
            return false
        }
        foreground = true
        if backgroundHolding && backgroundPermission != .allowed {
            updateBackgroundPermission(userRequestedPermission: true)
            message = "Allow location access for background holding, then tap Start again. You can turn background holding off for a foreground-only test."
            return false
        }
        // Validate first: a rejected draft must leave the current hold untouched.
        begin(first: first, route: route, speed: speed, area: area, name: name, timer: timer)
        return true
    }

    // Scheduled switches were explicitly chosen while foregrounded. They reuse
    // the connection without clearing location or requiring another UI start.
    private func begin(first: RoutePoint, route: PhoneRoute?, speed: Double,
                       area: IndoorArea?, name: String, timer: HoldTimerPlan?) {
        playback.cancel()
        timerTask?.cancel()
        holdTimer.prepare(timer)
        placeName = name
        self.route = route; self.point = first; self.speed = speed; meters = 0
        indoorMotion = area.map { IndoorMotion(area: $0) }
        retryCount = 0; sentAt = nil
        commandGaps = 0; longestCommandGap = 0; lastCommandTick = nil
        backgroundCommands = 0; locationCallbacks = 0
        phase = "starting"; markRestoreNeeded(true)
        message = "Opening this phone's developer location service…"
        UIApplication.shared.isIdleTimerDisabled = true
        updateBackgroundPermission()
        watchTimer()
        playback.start { [self] token in
            var restorePhase = area != nil ? "wandering" : route == nil ? "holding" : "driving"
            var recovering = false
            var failures = 0
            routeClock = ProcessInfo.processInfo.systemUptime
            while playback.accepts(token) {
                // After delayed execution/retries, do not send the old point
                // before processing a deadline that elapsed while suspended.
                if performTimerActionIfDue() { return }
                let tick = ProcessInfo.processInfo.systemUptime
                if phase == "driving", let path = self.route {
                    let elapsed = tick - routeClock
                    if elapsed > 5 {
                        phase = "paused"
                        message = "iOS delayed playback. Holding the last point; verify the phone before resuming."
                    } else {
                        meters = min(path.total, meters + elapsed * self.speed * 0.44704)
                        self.point = path.at(meters)
                        if meters >= path.total { phase = "arrived" }
                    }
                } else if phase == "wandering", var movement = indoorMotion {
                    let elapsed = tick - routeClock
                    if elapsed > 5 {
                        phase = "paused"
                        message = "iOS delayed movement. Holding the last point; verify the phone before resuming."
                    } else {
                        let next = movement.advance(seconds: elapsed)
                        if let previous = self.point { meters += previous.distance(to: next) }
                        self.point = next; indoorMotion = movement
                    }
                }
                routeClock = tick
                guard let target = self.point else { return }
                do {
                    try await bridge.set(target)
                    guard playback.accepts(token) else { return }
                    if performTimerActionIfDue() { return }
                    if holdTimer.plan != nil && holdTimer.deadline == nil {
                        holdTimer.acknowledge(at: timerNow)
                    }
                    sentAt = Date()
                    if visibility == "Background" { backgroundCommands += 1 }
                    let completed = ProcessInfo.processInfo.systemUptime
                    if let previous = lastCommandTick, completed - previous > 5 {
                        commandGaps += 1
                        longestCommandGap = max(longestCommandGap, completed - previous)
                    }
                    lastCommandTick = completed
                    if phase == "starting" || recovering {
                        phase = restorePhase
                        routeClock = ProcessInfo.processInfo.systemUptime
                        message = phase == "paused" ? "Reconnected. Holding the last point; resume when ready." : phase == "wandering" ? "Walking continuously inside your area. Check the actual location in Maps." : "Sending the selected location until you stop, while connected. Check Maps to verify."
                    }
                    recovering = false; failures = 0
                } catch {
                    guard playback.accepts(token) else { return }
                    if !recovering { restorePhase = (phase == "driving" || phase == "wandering" || (self.route != nil || indoorMotion != nil) && phase == "starting") ? "paused" : phase == "starting" ? "holding" : phase }
                    recovering = true; failures += 1; retryCount += 1
                    phase = "recovering"
                    // DeviceBridge exposes only our fixed, sanitized error strings.
                    message = "\(error.localizedDescription) Retrying this phone; Stop cancels retries."
                }
                let interval = recovering ? min(15.0, pow(2, Double(min(failures, 4)))) : (phase == "driving" || phase == "wandering") ? 0.25 : 1.0
                let delay = recovering ? interval : max(0.01, interval - (ProcessInfo.processInfo.systemUptime - tick))
                do { try await Task.sleep(nanoseconds: UInt64(delay * 1_000_000_000)) } catch { return }
            }
        }
    }

    private var timerNow: TimeInterval {
        let parts = timerOrigin.duration(to: .now).components
        return Double(parts.seconds) + Double(parts.attoseconds) / 1e18
    }

    var timerRemaining: TimeInterval? { holdTimer.remaining(at: timerNow) }

    private func watchTimer() {
        timerTask?.cancel(); timerTask = nil
        guard holdTimer.plan != nil else { return }
        timerTask = Task { [weak self] in
            while !Task.isCancelled {
                guard let self, self.holdTimer.plan != nil else { return }
                if self.performTimerActionIfDue() { return }
                do { try await Task.sleep(for: .milliseconds(250)) } catch { return }
            }
        }
    }

    @discardableResult
    func updateTimer(_ plan: HoldTimerPlan?, for expectedSession: UUID) -> Bool {
        guard sessionID == expectedSession, canReplace, plan == nil || plan!.valid else {
            message = "The session changed while this timer was open. Open its timer again to edit the current hold."
            return false
        }
        guard !performTimerActionIfDue() else { return false }
        holdTimer.prepare(plan); holdTimer.acknowledge(at: timerNow)
        watchTimer()
        return true
    }

    @discardableResult
    private func performTimerActionIfDue() -> Bool {
        let now = timerNow
        // Reading an unexpired deadline must not publish a state change and
        // force the map to redraw on every scheduler tick.
        guard let remaining = holdTimer.remaining(at: now), remaining <= 0,
              let ending = holdTimer.takeDue(at: now) else { return false }
        switch ending {
        case .restore: stop()
        case .switchTo(let place):
            begin(first: place.point, route: nil, speed: speed, area: nil, name: place.name, timer: nil)
        }
        return true
    }

    func extendTimer() {
        guard !performTimerActionIfDue() else { return }
        if !holdTimer.extend(by: 900, at: timerNow) {
            message = "A running timer can be extended up to 24 hours remaining."
        }
    }

    func removeTimer() {
        guard !performTimerActionIfDue() else { return }
        timerTask?.cancel(); timerTask = nil; holdTimer.cancel()
        message = "Timer removed. Holding continues until you stop, while connected."
    }

    func pauseResume() {
        guard phase == "driving" || phase == "wandering" || phase == "paused" else { return }
        phase = phase == "paused" ? (indoorMotion != nil ? "wandering" : "driving") : "paused"
        routeClock = ProcessInfo.processInfo.systemUptime
        message = phase == "paused" ? "Holding until you resume or stop." : phase == "wandering" ? "Walking continuously inside the selected area." : "Following the selected road route."
    }

    func stop() {
        guard phase != "stopping" else { return }
        playback.cancel()
        timerTask?.cancel(); timerTask = nil; holdTimer.cancel()
        phase = "stopping"
        message = "Stopping. Waiting for the current phone command before restoring…"
        Task {
            do {
                try await bridge.restore()
                phase = "idle"; point = nil; route = nil; indoorMotion = nil
                message = "Restore dispatched. Check Maps and each sharing app; confirm normal location below, or retry."
            } catch { phase = "restore-needed"; message = error.localizedDescription }
            UIApplication.shared.isIdleTimerDisabled = false
            updateBackgroundPermission()
        }
    }

    func confirmRestored() {
        // A user-observed restoration after restarting the phone also releases
        // the flag, so an expired pairing record can then be replaced.
        guard phase == "idle" || phase == "restore-needed" else { return }
        phase = "idle"; point = nil; route = nil; indoorMotion = nil
        markRestoreNeeded(false)
        updateBackgroundPermission()
        message = "Normal location confirmed by you. Ready for another session."
    }

    private func markRestoreNeeded(_ value: Bool) {
        needsRestore = value
        UserDefaults.standard.set(value, forKey: "needsRestore")
    }

    private var backgroundPermission: BackgroundPolicy.Permission {
        switch manager.authorizationStatus {
        case .authorizedAlways, .authorizedWhenInUse: return .allowed
        case .notDetermined: return .notDetermined
        default: return .denied
        }
    }

    func visibilityChanged(foreground: Bool, enteredBackground: Bool) {
        self.foreground = foreground
        visibility = foreground ? "Foreground" : enteredBackground ? "Background" : "Inactive"
        if performTimerActionIfDue() { return }
        if foreground { updateBackgroundPermission() }
        if enteredBackground && active && !backgroundRunning {
            backgroundStatus = "Waypoint left the screen without background support. Holding may stop; actual location is unknown."
        }
    }

    func requestBackgroundPermission() {
        updateBackgroundPermission(userRequestedPermission: true)
    }

    private func updateBackgroundPermission(userRequestedPermission: Bool = false) {
        let running = active && phase != "restore-needed"
        let action = BackgroundPolicy.action(enabled: backgroundHolding, sessionRunning: running,
            foreground: foreground, permission: backgroundPermission, serviceRunning: backgroundRunning,
            userRequestedPermission: userRequestedPermission && !requestingPermission)
        switch action {
        case .stop, .requestPermission:
            endBackgroundActivity()
            if !backgroundHolding {
                backgroundStatus = "Keep Waypoint open. Switching apps or locking can stop this hold."
            } else if backgroundPermission == .denied {
                backgroundStatus = "Location access is unavailable. Allow it in Settings > Apps > Waypoint > Location, or use foreground-only mode."
            } else if backgroundPermission == .notDetermined {
                backgroundStatus = "Allow While Using App when prompted, then start your session while Waypoint is open."
            } else {
                backgroundStatus = "Background access is allowed. It starts with your session; long holds still need testing."
            }
            if action == .requestPermission {
                requestingPermission = true
                manager.requestWhenInUseAuthorization()
            }
        case .start:
            let activity = CLBackgroundActivitySession()
            backgroundActivity = activity
            backgroundDiagnostic = "Background activity requested; waiting for iOS diagnostics."
            let token = UUID(); backgroundGeneration = token
            if #available(iOS 18.0, *) {
                diagnosticsTask = Task { [weak self] in
                    do {
                      for try await diagnostic in activity.diagnostics {
                        guard !Task.isCancelled, let self, self.backgroundGeneration == token else { return }
                        if diagnostic.authorizationDeniedGlobally {
                            self.backgroundDiagnostic = "iOS Location Services are off."
                        } else if diagnostic.authorizationDenied || diagnostic.authorizationRestricted {
                            self.backgroundDiagnostic = "iOS has denied or restricted location access."
                        } else if diagnostic.insufficientlyInUse {
                            self.backgroundDiagnostic = "iOS is not treating Waypoint as in use. Reopen it to resume background eligibility."
                        } else if diagnostic.serviceSessionRequired {
                            self.backgroundDiagnostic = "iOS requires a location authorization session. Background eligibility is unavailable."
                        } else if diagnostic.authorizationRequestInProgress {
                            self.backgroundDiagnostic = "Waiting for your answer to the location permission prompt."
                        } else {
                            self.backgroundDiagnostic = "iOS reports no background authorization blocker. This does not verify the simulated location."
                        }
                      }
                    } catch {
                        guard !Task.isCancelled, let self, self.backgroundGeneration == token else { return }
                        self.backgroundDiagnostic = "iOS background diagnostics stopped. The connection status and actual location need checking."
                    }
                }
            }
            manager.startUpdatingLocation()
            backgroundRunning = true
            backgroundStatus = "Background activity requested. Keep LocalDevVPN connected. iOS can still interrupt the session."
        case .keepRunning:
            break
        case .waitForForeground:
            backgroundStatus = "Reopen Waypoint to start background activity. Actual location is unknown."
        }
    }

    private func endBackgroundActivity() {
        backgroundGeneration = UUID()
        diagnosticsTask?.cancel(); diagnosticsTask = nil
        backgroundActivity?.invalidate(); backgroundActivity = nil
        manager.stopUpdatingLocation()
        backgroundRunning = false
        backgroundDiagnostic = "No background session is active."
    }

    nonisolated func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        // Delegate callbacks cannot promise actor isolation. Read our own manager
        // only after returning to the main actor; never transfer the callback's
        // non-Sendable CLLocationManager into the task.
        Task { @MainActor [weak self] in
            self?.requestingPermission = false
            self?.updateBackgroundPermission()
        }
    }
    nonisolated func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        // Do not store coordinates or mistake Core Location callbacks for an
        // independent check of what Maps or a sharing app is reporting.
        Task { @MainActor [weak self] in
            guard let self, self.backgroundRunning else { return }
            self.locationCallbacks += 1
        }
    }
    nonisolated func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        let denied = (error as? CLError)?.code == .denied
        Task { @MainActor [weak self] in
            guard let self, self.backgroundHolding, self.active else { return }
            if denied {
                self.endBackgroundActivity()
            }
            self.backgroundStatus = denied
                ? "Location access was denied. Keep Waypoint open; background holding is unavailable."
                : "iOS reported a location-service error. Background holding is uncertain; check the phone."
        }
    }
}
