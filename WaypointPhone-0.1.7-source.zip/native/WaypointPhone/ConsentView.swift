import SwiftUI

struct ConsentGate: View {
    @ObservedObject var session: PhoneSession
    @AppStorage("consent.v1.accepted") private var accepted = false
    @AppStorage("appearance") private var appearance = "system"

    var body: some View {
        Group {
            // Never hide recovery controls behind a new acknowledgement.
            if accepted || !session.canEdit {
                PhoneView(session: session)
            } else {
                ConsentView { accepted = true }
            }
        }
        .preferredColorScheme(appearance == "dark" ? .dark : appearance == "light" ? .light : nil)
    }
}

private struct ConsentView: View {
    var accept: () -> Void

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                Image(systemName: "location.circle.fill")
                    .font(.system(size: 64)).foregroundStyle(Color.waypoint)
                    .accessibilityHidden(true)
                Text("Before you use Waypoint")
                    .font(.largeTitle.bold()).accessibilityIdentifier("consentTitle")
                Text("Waypoint can change the location your phone reports. Other apps and linked accessories may show that location too.")
                Text("This is experimental, and cellular connections may fail. When you finish, use Stop & restore and check that your real location is back.")
                Text("By continuing, I consent to using these location simulation features on my own device.")
                    .font(.subheadline).foregroundStyle(.secondary)
            }
            .frame(maxWidth: 560, alignment: .leading)
            .padding(28).padding(.top, 24)
        }
        .background(Color.waypointSurface)
        .safeAreaInset(edge: .bottom) {
            Button("OK, I consent", action: accept)
                .buttonStyle(WaypointButton()).accessibilityIdentifier("acceptConsent")
                .frame(maxWidth: 560).padding(24).background(Color.waypointSurface)
        }
    }
}
