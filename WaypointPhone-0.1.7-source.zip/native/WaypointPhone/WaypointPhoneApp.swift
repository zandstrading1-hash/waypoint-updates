import SwiftUI
import MapKit
import UniformTypeIdentifiers

extension RoutePoint {
    var coordinate: CLLocationCoordinate2D { .init(latitude: latitude, longitude: longitude) }
    init(_ coordinate: CLLocationCoordinate2D) { self.init(latitude: coordinate.latitude, longitude: coordinate.longitude) }
}

@main
struct WaypointPhoneApp: App {
    @StateObject private var session = PhoneSession()
    #if WAYPOINT_UI_PREVIEW
    init() {
        // Set appearance before presenting any sheet in the isolated renderer.
        UserDefaults.standard.set(ProcessInfo.processInfo.arguments.contains("--preview-dark") ? "dark" : "light", forKey: "appearance")
        let arguments = ProcessInfo.processInfo.arguments
        if !arguments.contains("--preview-consent-preserve") {
            UserDefaults.standard.set(!arguments.contains("--preview-consent") && !arguments.contains("--preview-consent-restore"), forKey: "consent.v1.accepted")
        }
    }
    #endif
    var body: some Scene { WindowGroup { ConsentGate(session: session) } }
}
