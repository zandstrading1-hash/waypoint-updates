"""Render the real SwiftUI screens on an isolated simulator with no device bridge.

This is visual evidence only, never evidence of iPhone location behavior.
The normal build does not define WAYPOINT_UI_PREVIEW or include the stub.
"""
import argparse
import json
import hashlib
from pathlib import Path
import shutil
import subprocess
import time
import build
import ui_tests


def run(*args, **kwargs):
    return subprocess.run(args, check=True, **kwargs)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    scope = parser.add_mutually_exclusive_group()
    scope.add_argument("--connection-only", action="store_true",
                        help="Rerun the changed connection screen after the existing UI suite has passed")
    scope.add_argument("--consent-only", action="store_true",
                       help="Test consent in both themes, persistence, map access, and restoration access")
    args = parser.parse_args()
    test_source = build.ROOT / "tests/SearchUITests.swift"
    root = build.STATE / "ui-preview"
    root.mkdir(parents=True, exist_ok=True)
    sources = root / "source" / "WaypointPhone"
    sources.mkdir(parents=True, exist_ok=True)
    original_hashes = {source.name: hashlib.sha256(source.read_bytes()).hexdigest()
                       for source in (build.ROOT / "WaypointPhone").glob("*.swift")}
    for source in (build.ROOT / "WaypointPhone").glob("*.swift"):
        if source.name != "DeviceBridge.swift":
            shutil.copy2(source, sources / source.name)
    (sources / "DeviceBridge.swift").write_text('''import Foundation
final class DeviceBridge: Sendable {
    init(pairingURL: URL) {}
    func set(_ point: RoutePoint) async throws {}
    func restore() async throws {}
}
''')
    vendor = build.STATE / "native-vendor"
    vendor.mkdir(parents=True, exist_ok=True)
    build.ROOT = root / "source"
    project = build.project(root / "project", vendor)
    text = (project / "project.pbxproj").read_text()
    text = text.replace("com.zandstrading.waypoint.phone", "com.zandstrading.waypoint.preview")
    text = text.replace("SDKROOT = iphoneos; SUPPORTED_PLATFORMS = iphoneos;",
                        "SDKROOT = iphonesimulator; SUPPORTED_PLATFORMS = iphonesimulator;")
    (project / "project.pbxproj").write_text(text)
    # Info.plist's identifier must agree with the preview target.
    import plistlib
    info_path = project.parent / "Info.plist"
    info = plistlib.loads(info_path.read_bytes())
    info["CFBundleIdentifier"] = "com.zandstrading.waypoint.preview"
    info_path.write_bytes(plistlib.dumps(info))
    ui_tests.configure(project, test_source)
    inventory = json.loads(subprocess.check_output(["xcrun", "simctl", "list", "devices", "available", "--json"]))
    candidates = [device for group in inventory["devices"].values() for device in group
                  if device["name"] == "iPhone 17 Pro"]
    if not candidates:
        raise RuntimeError("iPhone 17 Pro simulator unavailable; visual QA remains blocked")
    device = candidates[-1]
    identifier = device["udid"]
    if device["state"] != "Booted":
        run("xcrun", "simctl", "boot", identifier)
    run("xcrun", "simctl", "bootstatus", identifier, "-b", timeout=240)
    run("xcodebuild", "build", "-project", str(project), "-scheme", "WaypointPhone",
        "-configuration", "Release", "-sdk", "iphonesimulator", "-destination", "id=" + identifier,
        "-derivedDataPath", str(root / "derived"), "SUPPORTED_PLATFORMS=iphonesimulator",
        "OTHER_LDFLAGS=", "SWIFT_ACTIVE_COMPILATION_CONDITIONS=WAYPOINT_UI_PREVIEW", "SWIFT_OPTIMIZATION_LEVEL=-Onone",
        "CODE_SIGNING_ALLOWED=NO", "CODE_SIGNING_REQUIRED=NO", timeout=300)
    app = root / "derived/Build/Products/Release-iphonesimulator/WaypointPhone.app"
    run("xcrun", "simctl", "install", identifier, str(app))
    screenshots = root / "screenshots"
    screenshots.mkdir(exist_ok=True)
    bundle = "com.zandstrading.waypoint.preview"
    for name, arguments in [
        ("map-light", ["--preview-light"]), ("map-dark", ["--preview-dark"]),
        ("session-dark", ["--preview-dark", "--preview-session"]),
        ("timer-light", ["--preview-light", "--preview-timer"]),
    ]:
        run("xcrun", "simctl", "launch", identifier, bundle, *arguments)
        time.sleep(10)  # Allow SwiftUI and network map tiles to render on CI.
        run("xcrun", "simctl", "io", identifier, "screenshot", str(screenshots / (name + ".png")))
        run("xcrun", "simctl", "terminate", identifier, bundle)
    result = root / "SearchUI.xcresult"
    selected_tests = (["-only-testing:SearchUITests/SearchUITests/testConnectionCheckCancellationAndResult"]
                      if args.connection_only else [])
    if args.consent_only:
        selected_tests = ["-only-testing:SearchUITests/SearchUITests/" + name for name in
                          ("testConsentLight", "testConsentDark", "testConsentPreservesRestoration")]
    try:
        run("xcodebuild", "test", "-project", str(project), "-scheme", "WaypointPhone",
            "-configuration", "Release", "-destination", "id=" + identifier,
            "-derivedDataPath", str(root / "derived"), "-resultBundlePath", str(result),
            "-parallel-testing-enabled", "NO", "-maximum-concurrent-test-simulator-destinations", "1",
            "SUPPORTED_PLATFORMS=iphonesimulator", "OTHER_LDFLAGS=",
            "SWIFT_ACTIVE_COMPILATION_CONDITIONS=WAYPOINT_UI_PREVIEW", "SWIFT_OPTIMIZATION_LEVEL=-Onone",
            "CODE_SIGNING_ALLOWED=NO", "CODE_SIGNING_REQUIRED=NO", *selected_tests, timeout=480)
    finally:
        if result.exists():
            run("xcrun", "xcresulttool", "export", "attachments", "--path", str(result),
                "--output-path", str(screenshots / "interactions"))
            summary = subprocess.check_output(["xcrun", "xcresulttool", "get", "test-results", "summary", "--path", str(result)])
            (screenshots / "ui-test-summary.json").write_bytes(summary)
    (screenshots / "receipt.json").write_text(json.dumps({
        "device": "iPhone 17 Pro simulator", "bridge": "no-device stub",
        "scope": "real SwiftUI screens and XCTest search interactions with fictional search responses; not physical device evidence",
        "interaction_tests": "passed",
        "test_scope": ("consent, persistence, map and restoration access" if args.consent_only else
                       "connection cancellation/result only" if args.connection_only else "full UI suite"),
        "commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "source_sha256": original_hashes,
    }, indent=2))


if __name__ == "__main__":
    main()
