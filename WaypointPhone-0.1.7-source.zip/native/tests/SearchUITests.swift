import XCTest

@MainActor final class SearchUITests: XCTestCase {
    func capture(_ name: String) {
        let attachment = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        attachment.name = name; attachment.lifetime = .keepAlways; add(attachment)
    }
    func launch(_ theme: String, extra: [String] = []) -> XCUIApplication {
        continueAfterFailure = false
        let app = XCUIApplication(bundleIdentifier: "com.zandstrading.waypoint.preview")
        app.launchArguments = ["--preview-\(theme)", "--ui-tests"] + extra
        app.launch(); return app
    }
    func open(_ app: XCUIApplication) -> XCUIElement {
        XCTAssertTrue(app.buttons["openSearch"].waitForExistence(timeout: 15))
        app.buttons["openSearch"].tap()
        let field = app.textFields["placeQuery"]
        XCTAssertTrue(field.waitForExistence(timeout: 10)); field.tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 5))
        return field
    }
    func exercise(_ theme: String) {
        let app = launch(theme)
        var field = open(app)
        field.typeText("library")
        capture("search-keyboard-\(theme)")
        app.buttons["clearSearch"].tap()
        XCTAssertEqual(field.value as? String, "")
        XCTAssertFalse(app.buttons["clearSearch"].exists)
        XCTAssertFalse(app.buttons["submitSearch"].isEnabled)
        capture("search-cleared-\(theme)")
        app.buttons["cancelSearch"].tap()
        XCTAssertTrue(field.waitForNonExistence(timeout: 5))
        XCTAssertEqual(app.staticTexts["selectedPlace"].label, "City Library")
        field = open(app)
        XCTAssertEqual(field.value as? String, "")
        field.typeText("library")
        app.buttons["submitSearch"].tap()
        XCTAssertTrue(app.buttons["searchResult0"].waitForExistence(timeout: 10))
        XCTAssertTrue(app.keyboards.firstMatch.waitForNonExistence(timeout: 5))
        capture("search-results-\(theme)")
        app.buttons["searchResult0"].tap()
        XCTAssertTrue(field.waitForNonExistence(timeout: 5))
        XCTAssertEqual(app.staticTexts["selectedPlace"].label, "Test Library")
        XCTAssertTrue(app.buttons["Stop & restore"].exists)
        capture("search-returned-map-\(theme)")
        field = open(app)
        field.typeText("42.3315, -83.047")
        app.buttons["submitSearch"].tap()
        XCTAssertTrue(app.buttons["searchResult0"].waitForExistence(timeout: 5))
        app.buttons["searchResult0"].tap()
        XCTAssertTrue(field.waitForNonExistence(timeout: 5))
        XCTAssertEqual(app.staticTexts["selectedPlace"].label, "Coordinates")
        app.terminate()
    }
    func testSearchLight() { exercise("light") }
    func testSearchDark() { exercise("dark") }
    func exerciseConsent(_ theme: String) {
        let app = launch(theme, extra: ["--preview-consent"])
        XCTAssertTrue(app.staticTexts["consentTitle"].waitForExistence(timeout: 15))
        XCTAssertFalse(app.buttons["openSearch"].exists)
        XCTAssertTrue(app.buttons["acceptConsent"].isHittable)
        capture("consent-\(theme)")
        app.buttons["acceptConsent"].tap()
        let field = open(app)
        app.buttons["cancelSearch"].tap()
        XCTAssertTrue(field.waitForNonExistence(timeout: 5))
        app.terminate()
        app.launchArguments = ["--preview-\(theme)", "--ui-tests", "--preview-consent-preserve"]
        app.launch()
        XCTAssertTrue(app.buttons["openSearch"].waitForExistence(timeout: 15))
        XCTAssertFalse(app.buttons["acceptConsent"].exists)
        capture("consent-accepted-relaunch-\(theme)")
        app.terminate()
    }
    func testConsentLight() { exerciseConsent("light") }
    func testConsentDark() { exerciseConsent("dark") }
    func testConsentPreservesRestoration() {
        let app = launch("light", extra: ["--preview-consent-restore"])
        XCTAssertTrue(app.buttons["Stop & restore"].waitForExistence(timeout: 15))
        XCTAssertFalse(app.buttons["acceptConsent"].exists)
        let confirm = app.buttons["I checked: normal location is restored"]
        if !confirm.isHittable { app.swipeUp() }
        XCTAssertTrue(confirm.isHittable)
        capture("consent-restoration-accessible")
        confirm.tap()
        XCTAssertTrue(app.buttons["acceptConsent"].waitForExistence(timeout: 5))
        app.buttons["acceptConsent"].tap()
        XCTAssertTrue(app.buttons["openSearch"].waitForExistence(timeout: 10))
        app.terminate()
    }
    func testEmptyErrorAndCancellation() {
        let app = launch("light")
        let field = open(app)
        for query in ["no matches", "offline", "91, 181"] {
            field.typeText(query); app.buttons["submitSearch"].tap()
            XCTAssertTrue(app.descendants(matching: .any)["searchMessage"].firstMatch.waitForExistence(timeout: 8))
            XCTAssertFalse(app.buttons["searchResult0"].exists)
            capture("search-message-\(query == "offline" ? "offline" : query == "no matches" ? "empty" : "invalid")")
            app.buttons["clearSearch"].tap()
        }
        field.typeText("slow"); app.buttons["submitSearch"].tap()
        app.buttons["clearSearch"].tap()
        XCTAssertEqual(field.value as? String, "")
        // A cancelled delayed response must not put a stale result back on screen.
        let stale = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == true"), object: app.buttons["searchResult0"])
        XCTAssertEqual(XCTWaiter.wait(for: [stale], timeout: 3), .timedOut)
        app.buttons["cancelSearch"].tap()
        XCTAssertTrue(field.waitForNonExistence(timeout: 5)); app.terminate()
    }
    func testLivePublicAddressLookup() {
        continueAfterFailure = false
        let app = XCUIApplication(bundleIdentifier: "com.zandstrading.waypoint.preview")
        // No --ui-tests flag: this exercises the production MapKit lookup.
        app.launchArguments = ["--preview-light"]
        app.launch()
        let field = open(app)
        field.typeText("Detroit Public Library, Detroit, Michigan")
        app.buttons["submitSearch"].tap()
        XCTAssertTrue(app.buttons["searchResult0"].waitForExistence(timeout: 30))
        capture("search-live-public-address")
        app.buttons["searchResult0"].tap()
        XCTAssertTrue(field.waitForNonExistence(timeout: 5))
        app.terminate()
    }
    func testTimerDestinationAndCompactLayout() {
        let app = launch("light", extra: ["--preview-timer"])
        let destination = app.buttons["timerDestination"]
        XCTAssertTrue(destination.waitForExistence(timeout: 15)); destination.tap()
        XCTAssertTrue(app.buttons["destinationSearch"].waitForExistence(timeout: 5))
        app.buttons["destinationSearch"].tap()
        let field = app.textFields["placeQuery"]
        XCTAssertTrue(field.waitForExistence(timeout: 5)); field.tap(); field.typeText("library")
        app.buttons["submitSearch"].tap()
        XCTAssertTrue(app.buttons["searchResult0"].waitForExistence(timeout: 5))
        app.buttons["searchResult0"].tap()
        XCTAssertTrue(field.waitForNonExistence(timeout: 5))
        capture("timer-destination-selected")
        app.buttons["Use Test Library"].tap()
        app.buttons["Cancel"].tap()
        XCTAssertEqual(app.staticTexts["selectedPlace"].label, "City Library")
        app.buttons["More options"].tap()
        let compact = app.switches["compactHeader"]
        XCTAssertTrue(compact.waitForExistence(timeout: 5))
        if !compact.isHittable { app.swipeUp() }
        compact.tap()
        app.buttons["closeOptions"].tap()
        capture("map-compact-light")
        _ = open(app)
        app.buttons["cancelSearch"].tap()
        app.terminate()
    }

    func testOptionsLight() { options("light") }
    func testOptionsDark() { options("dark") }
    func testConnectionCheckCancellationAndResult() {
        let app = launch("dark", extra: ["--preview-connection-check"])
        XCTAssertTrue(app.buttons["More options"].waitForExistence(timeout: 15))
        app.buttons["More options"].tap()
        for _ in 0..<5 {
            if app.buttons["phoneSetup"].isHittable { break }
            app.swipeUp()
        }
        app.buttons["phoneSetup"].tap()
        let check = app.buttons["checkConnection"]
        for _ in 0..<5 {
            if check.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(check.isEnabled)
        check.tap()
        XCTAssertEqual(check.label, "Cancel check")
        capture("connection-check-pending-dark")
        check.tap()
        let result = app.staticTexts["connectionCheckResult"]
        let stale = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == true"), object: result)
        XCTAssertEqual(XCTWaiter.wait(for: [stale], timeout: 3), .timedOut)
        check.tap()
        XCTAssertTrue(result.waitForExistence(timeout: 5))
        XCTAssertEqual(result.label, "Local connection refused")
        XCTAssertEqual(check.label, "Check connection")
        for _ in 0..<4 {
            if result.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(result.isHittable)
        capture("connection-check-dark")
        app.navigationBars.buttons.element(boundBy: 0).tap()
        app.buttons["closeOptions"].tap()
        XCTAssertTrue(app.buttons["More options"].waitForExistence(timeout: 5))
        app.terminate()
    }
    func options(_ theme: String) {
        let app = launch(theme)
        XCTAssertTrue(app.buttons["More options"].waitForExistence(timeout: 15))
        app.buttons["More options"].tap()
        XCTAssertTrue(app.buttons["mode-Area"].waitForExistence(timeout: 5))
        capture("options-top-\(theme)")
        app.buttons["mode-Area"].tap()
        let version = app.staticTexts["optionsVersion"]
        for _ in 0..<5 {
            if version.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(version.isHittable, "Options must scroll all the way to the bottom")
        capture("options-bottom-\(theme)")
        app.buttons["updatesHelp"].tap()
        XCTAssertTrue(app.staticTexts["Refresh before 7 days"].waitForExistence(timeout: 5))
        capture("options-expiry-\(theme)")
        app.navigationBars.buttons.element(boundBy: 0).tap()
        app.buttons["phoneSetup"].tap()
        XCTAssertTrue(app.navigationBars["Phone setup"].waitForExistence(timeout: 5))
        capture("options-setup-\(theme)")
        app.navigationBars.buttons.element(boundBy: 0).tap()
        for _ in 0..<5 {
            if app.buttons["mode-Hold"].isHittable { break }
            app.swipeDown()
        }
        app.buttons["theme-\(theme == "light" ? "dark" : "light")"].tap()
        app.buttons["closeOptions"].tap()
        capture("map-theme-transition-from-\(theme)")
        app.buttons["More options"].tap()
        app.buttons["theme-\(theme)"].tap()
        app.buttons["closeOptions"].tap()
        XCTAssertTrue(app.buttons["Draw movement area"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.buttons["Stop & restore"].exists, "Changing a draft mode must preserve the current session")
        capture("area-continuous-\(theme)")
        // Reopening and dismissing must remain responsive after navigation.
        app.buttons["More options"].tap()
        XCTAssertTrue(app.buttons["mode-Hold"].waitForExistence(timeout: 5))
        app.buttons["mode-Hold"].tap()
        app.buttons["closeOptions"].tap()
        XCTAssertEqual(app.staticTexts["selectedPlace"].label, "City Library")
        app.terminate()
    }
}
