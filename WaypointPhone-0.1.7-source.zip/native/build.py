"""Prepare on Windows/macOS; compile an unsigned arm64 IPA only with Xcode on macOS.

No Apple login, signing key, pairing file or global install is used.
The script itself never dispatches a cloud job.
"""
import argparse
import hashlib
import json
from pathlib import Path
import plistlib
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parent
STATE = ROOT.parent / ".waypoint"
ICON_SOURCE = ROOT / "Artwork" / "WaypointIcon.png"
UPSTREAM = "4bdfc92aa7cebd7a534f1e1ef56415f5727402de"
ASSETS = {
    "idevice.h": "696286794e8cf1c18a91d4dab5046cef4d9bae352f5e7a1ad33fbc0ba30d7ab4",
    "libidevice_ffi.a": "4db23fe1d342927b9480bb9a8577f219994365621dc28aa0018e23ea1990ecc8",
    "module.modulemap": "d98e25796e1135d892d81e6922a61e78e82b3d6c33322112e9eca1e089c7a300",
}


def dependencies():
    destination = STATE / "native-vendor"
    destination.mkdir(parents=True, exist_ok=True)
    for name, digest in ASSETS.items():
        path = destination / name
        if path.exists() and hashlib.sha256(path.read_bytes()).hexdigest() == digest:
            continue
        print("Fetching pinned native dependency:", name, flush=True)
        url = f"https://raw.githubusercontent.com/StikDebug/StikDebug/{UPSTREAM}/StikDebug/idevice/{name}"
        with urllib.request.urlopen(url, timeout=60) as response:
            data = response.read(70_000_001)
        if len(data) > 70_000_000 or hashlib.sha256(data).hexdigest() != digest:
            raise RuntimeError(f"Checksum mismatch for {name}; refusing to build.")
        path.write_bytes(data)
    return destination


def project(folder, vendor):
    """Generate an ordinary Xcode project without installing a project generator."""
    folder.mkdir(parents=True, exist_ok=True)
    # Preserve the generated master; Apple tooling exports the required icon size.
    catalog = folder / "Assets.xcassets"
    icon_set = catalog / "AppIcon.appiconset"
    icon_set.mkdir(parents=True, exist_ok=True)
    icon_png = icon_set / "AppIcon.png"
    if sys.platform == "darwin":
        subprocess.run(["sips", "--resampleHeightWidth", "1024", "1024", str(ICON_SOURCE), "--out", str(icon_png)], check=True)
    else:
        # --prepare is inspection only; the Mac build regenerates this export.
        shutil.copy2(ICON_SOURCE, icon_png)
    (catalog / "Contents.json").write_text(json.dumps({"info": {"author": "xcode", "version": 1}}), encoding="utf-8")
    (icon_set / "Contents.json").write_text(json.dumps({
        "images": [{"filename": "AppIcon.png", "idiom": "universal", "platform": "ios", "size": "1024x1024"}],
        "info": {"author": "xcode", "version": 1},
    }, indent=2), encoding="utf-8")
    objects = []

    def ident(value):
        return hashlib.sha256(value.encode()).hexdigest()[:24].upper()

    def quoted(value):
        return json.dumps(str(value))

    def add(name, body):
        value = ident(name)
        objects.append(f"{value} = {{ {body} }};")
        return value

    files, builds = [], []
    for source in sorted((ROOT / "WaypointPhone").glob("*.swift")):
        ref = add(source.name, f'isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = {quoted(source.as_posix())}; sourceTree = "<absolute>";')
        files.append(ref)
        builds.append(add("compile:" + source.name, f"isa = PBXBuildFile; fileRef = {ref};"))
    assets = add("assets", f'isa = PBXFileReference; lastKnownFileType = folder.assetcatalog; path = {quoted(catalog.as_posix())}; sourceTree = "<absolute>";')
    files.append(assets)
    asset_build = add("compile:assets", f"isa = PBXBuildFile; fileRef = {assets};")
    resources = add("resources", f'isa = PBXResourcesBuildPhase; buildActionMask = 2147483647; files = ({asset_build},); runOnlyForDeploymentPostprocessing = 0;')
    product = add("product", 'isa = PBXFileReference; explicitFileType = wrapper.application; path = WaypointPhone.app; sourceTree = BUILT_PRODUCTS_DIR;')
    products = add("products", f'isa = PBXGroup; name = Products; children = ({product},); sourceTree = "<group>";')
    group = add("group", f'isa = PBXGroup; children = ({",".join(files + [products])},); sourceTree = "<group>";')
    sources = add("sources", f'isa = PBXSourcesBuildPhase; buildActionMask = 2147483647; files = ({",".join(builds)},); runOnlyForDeploymentPostprocessing = 0;')
    frameworks = add("frameworks", "isa = PBXFrameworksBuildPhase; buildActionMask = 2147483647; files = (); runOnlyForDeploymentPostprocessing = 0;")
    target_config = add("target-config", f'''isa = XCBuildConfiguration; name = Release; buildSettings = {{
        PRODUCT_NAME = WaypointPhone; PRODUCT_BUNDLE_IDENTIFIER = com.zandstrading.waypoint.phone;
        SDKROOT = iphoneos; SUPPORTED_PLATFORMS = iphoneos; ARCHS = arm64;
        IPHONEOS_DEPLOYMENT_TARGET = 17.4; SWIFT_VERSION = 6.0;
        SWIFT_OPTIMIZATION_LEVEL = "-O"; CLANG_ENABLE_MODULES = YES;
        CODE_SIGNING_ALLOWED = NO; CODE_SIGNING_REQUIRED = NO;
        GENERATE_INFOPLIST_FILE = NO; INFOPLIST_FILE = {quoted((folder / 'Info.plist').as_posix())};
        ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon;
        ASSETCATALOG_COMPILER_GENERATE_SWIFT_ASSET_SYMBOL_EXTENSIONS = NO;
        TARGETED_DEVICE_FAMILY = 1; SKIP_INSTALL = NO; INSTALL_PATH = "$(LOCAL_APPS_DIR)";
        SWIFT_INCLUDE_PATHS = ({quoted(vendor.as_posix())},);
        HEADER_SEARCH_PATHS = ({quoted(vendor.as_posix())},);
        LIBRARY_SEARCH_PATHS = ({quoted(vendor.as_posix())},);
        OTHER_LDFLAGS = ("-lidevice_ffi", "-lz", "-liconv", "-lresolv", "-lc++", "-framework", Security, "-framework", SystemConfiguration, "-framework", CFNetwork, "-framework", Network,);
        LD_RUNPATH_SEARCH_PATHS = "@executable_path/Frameworks";
    }};''')
    project_config = add("project-config", "isa = XCBuildConfiguration; name = Release; buildSettings = { CLANG_ENABLE_MODULES = YES; }; ")
    target_configs = add("target-configs", f"isa = XCConfigurationList; buildConfigurations = ({target_config},); defaultConfigurationIsVisible = 0; defaultConfigurationName = Release;")
    project_configs = add("project-configs", f"isa = XCConfigurationList; buildConfigurations = ({project_config},); defaultConfigurationIsVisible = 0; defaultConfigurationName = Release;")
    target = add("target", f'isa = PBXNativeTarget; name = WaypointPhone; productName = WaypointPhone; productType = "com.apple.product-type.application"; productReference = {product}; buildConfigurationList = {target_configs}; buildPhases = ({sources},{frameworks},{resources},); buildRules = (); dependencies = ();')
    root = add("project", f'isa = PBXProject; attributes = {{ LastUpgradeCheck = 2600; }}; buildConfigurationList = {project_configs}; compatibilityVersion = "Xcode 14.0"; developmentRegion = en; knownRegions = (en,Base,); mainGroup = {group}; productRefGroup = {products}; projectDirPath = ""; projectRoot = ""; targets = ({target},);')
    xcode = folder / "WaypointPhone.xcodeproj"
    xcode.mkdir(exist_ok=True)
    (xcode / "project.pbxproj").write_text("// !$*UTF8*$!\n{ archiveVersion = 1; classes = {}; objectVersion = 56; objects = {\n" + "\n".join(objects) + f"\n}}; rootObject = {root}; }}\n", encoding="utf-8")
    schemes = xcode / "xcshareddata" / "xcschemes"
    schemes.mkdir(parents=True, exist_ok=True)
    reference = f'<BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target}" BuildableName="WaypointPhone.app" BlueprintName="WaypointPhone" ReferencedContainer="container:WaypointPhone.xcodeproj"/>'
    (schemes / "WaypointPhone.xcscheme").write_text(f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="2600" version="1.7">
  <BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries>
    <BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES">{reference}</BuildActionEntry>
  </BuildActionEntries></BuildAction>
  <LaunchAction buildConfiguration="Release" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" debugServiceExtension="internal" allowLocationSimulation="YES">
    <BuildableProductRunnable runnableDebuggingMode="0">{reference}</BuildableProductRunnable>
  </LaunchAction>
  <AnalyzeAction buildConfiguration="Release"/>
  <ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/>
</Scheme>''', encoding="utf-8")
    info = {
        "CFBundleDevelopmentRegion": "en", "CFBundleExecutable": "WaypointPhone",
        "CFBundleIdentifier": "com.zandstrading.waypoint.phone", "CFBundleName": "Waypoint",
        "CFBundleDisplayName": "Waypoint", "CFBundlePackageType": "APPL",
        "CFBundleShortVersionString": "0.1.7", "CFBundleVersion": "9",
        "LSRequiresIPhoneOS": True, "MinimumOSVersion": "17.4",
        "UILaunchScreen": {}, "UISupportedInterfaceOrientations": ["UIInterfaceOrientationPortrait"],
        "UIApplicationSceneManifest": {"UIApplicationSupportsMultipleScenes": False},
        "NSLocalNetworkUsageDescription": "Connect to this iPhone's developer service through its local VPN.",
        "NSLocationWhenInUseUsageDescription": "Keep your explicitly started location session running when you leave Waypoint.",
        "NSLocationAlwaysAndWhenInUseUsageDescription": "Keep your explicitly started location session running in the background until you stop it.",
        "UIBackgroundModes": ["location"],
    }
    with (folder / "Info.plist").open("wb") as stream:
        plistlib.dump(info, stream)
    (folder / "build-inputs.json").write_text(json.dumps({
        "upstream_commit": UPSTREAM, "dependency_sha256": ASSETS,
        "source_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT / "WaypointPhone").glob("*.swift"))},
        "artwork_sha256": {ICON_SOURCE.name: hashlib.sha256(ICON_SOURCE.read_bytes()).hexdigest()},
        "status": "prepared, not compiled or tested on a phone",
    }, indent=2), encoding="utf-8")
    return xcode


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prepare", action="store_true", help="Verify dependencies and generate the project only")
    args = parser.parse_args()
    if not args.prepare and (sys.platform != "darwin" or not shutil.which("xcodebuild")):
        parser.error("Compiling an IPA requires macOS with Xcode. Use --prepare for source/dependency preparation only.")
    vendor = dependencies()
    parent = STATE / "native-build"
    parent.mkdir(parents=True, exist_ok=True)
    folder = Path(tempfile.mkdtemp(prefix="run-", dir=parent))
    xcode = project(folder, vendor)
    if args.prepare:
        print("Prepared:", xcode)
        print("No IPA was built. Run this script without --prepare on a Mac with Xcode.")
        return
    # Run the platform-independent Swift route checks before compiling the iOS app.
    check = folder / "route-checks"
    subprocess.run(["xcrun", "swiftc", "-swift-version", "6",
                    str(ROOT / "WaypointPhone" / "Route.swift"),
                    str(ROOT / "WaypointPhone" / "IndoorMotion.swift"),
                    str(ROOT / "WaypointPhone" / "BackgroundPolicy.swift"),
                    str(ROOT / "WaypointPhone" / "SessionPlayback.swift"),
                    str(ROOT / "WaypointPhone" / "HoldTimer.swift"),
                    str(ROOT / "WaypointPhone" / "ConnectionCheck.swift"),
                    str(ROOT / "tests" / "RouteChecks.swift"),
                    str(ROOT / "tests" / "BackgroundChecks.swift"),
                    str(ROOT / "tests" / "PlaybackChecks.swift"),
                    str(ROOT / "tests" / "TimerChecks.swift"),
                    str(ROOT / "tests" / "ConnectionChecks.swift"),
                    str(ROOT / "tests" / "IndoorChecks.swift"), "-o", str(check)], check=True)
    subprocess.run([str(check)], check=True)
    archive = folder / "WaypointPhone.xcarchive"
    subprocess.run(["xcodebuild", "archive", "-project", str(xcode), "-scheme", "WaypointPhone",
                    "-configuration", "Release", "-archivePath", str(archive), "-sdk", "iphoneos",
                    "-destination", "generic/platform=iOS", "CODE_SIGNING_ALLOWED=NO",
                    "CODE_SIGNING_REQUIRED=NO", "CODE_SIGN_IDENTITY="], check=True)
    app = archive / "Products" / "Applications" / "WaypointPhone.app"
    if not (app / "WaypointPhone").is_file():
        raise RuntimeError("Archive did not contain an iPhone app executable.")
    compiled_info = plistlib.loads((app / "Info.plist").read_bytes())
    primary_icon = compiled_info.get("CFBundleIcons", {}).get("CFBundlePrimaryIcon", {})
    if primary_icon.get("CFBundleIconName") != "AppIcon" or not (app / "Assets.car").is_file():
        raise RuntimeError("The compiled archive is missing its app icon.")
    # Preserve attribution in the application bundle as well as source.
    shutil.copy2(ROOT / "LICENSE", app / "LICENSE.txt")
    shutil.copy2(ROOT / "THIRD_PARTY.md", app / "THIRD_PARTY.txt")
    shutil.copy2(ROOT / "IDEVICE-LICENSE.txt", app / "IDEVICE-LICENSE.txt")
    ipa = folder / "WaypointPhone-unsigned.ipa"
    with zipfile.ZipFile(ipa, "w", compression=zipfile.ZIP_DEFLATED) as package:
        for path in sorted(app.rglob("*")):
            if path.is_file():
                package.write(path, "Payload/WaypointPhone.app/" + path.relative_to(app).as_posix())
    digest = hashlib.sha256(ipa.read_bytes()).hexdigest()
    ipa.with_suffix(".ipa.sha256").write_text(f"{digest}  {ipa.name}\n", encoding="utf-8")
    inputs = json.loads((folder / "build-inputs.json").read_text(encoding="utf-8"))
    try:
        commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
        dirty = bool(subprocess.check_output(["git", "status", "--porcelain"], cwd=ROOT, text=True).strip())
    except (OSError, subprocess.CalledProcessError):
        commit, dirty = None, None
    receipt = {
        **inputs,
        "status": "compiled unsigned; not signed, installed or phone-tested",
        "commit": commit, "working_tree_dirty": dirty,
        "xcode": subprocess.check_output(["xcodebuild", "-version"], text=True).strip(),
        "iphoneos_sdk": subprocess.check_output(["xcrun", "--sdk", "iphoneos", "--show-sdk-version"], text=True).strip(),
        "route_math_checks": "passed",
        "indoor_geometry_checks": "passed; 322000 simulated steps; not physical phone evidence",
        "background_policy_checks": "passed; permission and lifecycle decisions only; not iOS background execution evidence",
        "playback_lifecycle_checks": "passed; blocked-command replacement and Stop cancellation; not native transport evidence",
        "hold_timer_checks": "passed; deterministic deadlines, actions and blocked-command cancellation; not iOS scheduling evidence",
        "connection_check_checks": "passed; completion, cancellation, timeout and stale-result isolation with fake drivers; not cellular evidence",
        "app_icon_checks": "compiled asset catalog and primary app icon metadata present",
        "ipa": ipa.name, "ipa_sha256": digest,
    }
    (folder / "build-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print("Unsigned IPA:", ipa)
    print("SHA-256:", digest)
    print("It still needs personal signing/sideloading and physical iPhone acceptance testing.")


if __name__ == "__main__":
    main()
